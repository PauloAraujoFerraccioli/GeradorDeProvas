package com.geradorprovas.dao;

import com.geradorprovas.util.Conexao;
import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class QuestaoDAOTest1 {

    private QuestaoDAO dao;
    // Variável constante de disciplina para testes
    private static final String DISCIPLINA_TESTE = "Programação";
    private static final String DISCIPLINA_FISICA = "Fisica";
    private static final String DISCIPLINA_QUIMICA = "Quimica";

    @BeforeEach
    void setUp() {
        this.dao = new QuestaoDAO();
        limparBancoDeDados();
    }

    @AfterEach
    void tearDown() {
        limparBancoDeDados();
    }

    private void limparBancoDeDados() {
        // Assume-se que a classe Conexao está configurada para testes.
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute("SET FOREIGN_KEY_CHECKS = 0");
            // Nomes de tabelas ajustados
            stmt.execute("TRUNCATE TABLE alternativa");
            stmt.execute("TRUNCATE TABLE questao");
            stmt.execute("SET FOREIGN_KEY_CHECKS = 1");

        } catch (SQLException e) {
            fail("Falha na limpeza do banco de dados. Verifique a conexão. Erro: " + e.getMessage());
        }
    }

    @Test
    void deveSalvarQuestaoEAlternativasCorretamenteComTransacao() throws SQLException {
        // Uso da constante para garantir consistência
        Questao novaQuestao = new Questao("Qual o nome do criador da linguagem Java?", DISCIPLINA_TESTE);

        // Assumindo que a classe Questao tem o método adicionarAlternativa()
        novaQuestao.adicionarAlternativa(new Alternativa("Linus Torvalds", false));
        novaQuestao.adicionarAlternativa(new Alternativa("James Gosling", true));
        novaQuestao.adicionarAlternativa(new Alternativa("Guido van Rossum", false));
        novaQuestao.adicionarAlternativa(new Alternativa("Bjarne Stroustrup", false));

        dao.cadastrarQuestao(novaQuestao);

        // Pega o ID REAL gerado pelo DAO e verifica se é válido
        Long idGerado = novaQuestao.getId();
        assertTrue(idGerado != null && idGerado > 0, "O ID gerado deve ser positivo, indicando sucesso na inserção.");

        // CORREÇÃO: Passando a disciplina para o método de busca
        List<Questao> questoesSalvas = dao.buscarTodasQuestoes(DISCIPLINA_TESTE);

        assertEquals(1, questoesSalvas.size(), "Deve haver exatamente 1 questão salva no banco.");

        Questao qSalva = questoesSalvas.get(0);
        assertEquals(idGerado, qSalva.getId(), "O ID da questão buscada deve coincidir com o ID gerado.");
        assertEquals(DISCIPLINA_TESTE, qSalva.getDisciplina(), "A disciplina deve ser salva corretamente.");
        assertEquals(4, qSalva.getAlternativas().size(), "O número de alternativas salvas deve ser 4.");

        long corretas = qSalva.getAlternativas().stream().filter(Alternativa::isCorreta).count();
        assertEquals(1, corretas, "Deve haver exatamente 1 alternativa marcada como correta.");

        Optional<Alternativa> respostaCorreta = qSalva.getAlternativas().stream()
                .filter(Alternativa::isCorreta)
                .findFirst();

        assertTrue(respostaCorreta.isPresent(), "Deve haver uma alternativa correta.");
        assertEquals("James Gosling", respostaCorreta.get().getTexto(), "O texto da alternativa correta está incorreto.");
    }

    @Test
    void deveBuscarTodasAsDisciplinasUnicas() throws SQLException {
        dao.cadastrarQuestao(new Questao("Q1", DISCIPLINA_FISICA));
        dao.cadastrarQuestao(new Questao("Q2", DISCIPLINA_QUIMICA));
        dao.cadastrarQuestao(new Questao("Q3", DISCIPLINA_FISICA)); // Disciplina repetida

        List<String> disciplinas = dao.buscarDisciplinas();

        assertEquals(2, disciplinas.size(), "Deve retornar apenas as disciplinas únicas.");

        // Verifica o conteúdo, assumindo ORDER BY alfabético no DAO
        assertTrue(disciplinas.contains(DISCIPLINA_FISICA), "Deve conter a disciplina Fisica.");
        assertTrue(disciplinas.contains(DISCIPLINA_QUIMICA), "Deve conter a disciplina Quimica.");

        // Se a ordem for importante:
        // assertEquals(Arrays.asList(DISCIPLINA_FISICA, DISCIPLINA_QUIMICA), disciplinas, "As disciplinas devem ser buscadas em ordem alfabética.");
    }

    @Test
    void deveRetornarListaVaziaSeBancoEstiverVazio() throws SQLException {
        // CORREÇÃO: É necessário passar uma disciplina válida para a busca
        List<Questao> todas = dao.buscarTodasQuestoes(DISCIPLINA_TESTE);

        assertTrue(todas.isEmpty(), "A lista de questões deve ser vazia quando o banco está limpo.");

        List<String> disciplinas = dao.buscarDisciplinas();

        assertTrue(disciplinas.isEmpty(), "A lista de disciplinas deve ser vazia quando o banco está limpo.");
    }
}