package com.geradorprovas.util;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class GeradorPDF {

    private static final Font FONT_TITULO = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
    private static final Font FONT_CABECALHO = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_ENUNCIADO = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    private static final Font FONT_ALTERNATIVA = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_MARCADOR = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);

    public GeradorPDF() { }

    public void gerar(String curso, String turmaTurno, List<Questao> questoesSelecionadas, String disciplina,
                      String professor, String dataProva, String caminhoCompleto)
            throws DocumentException, IOException {

        if (caminhoCompleto == null || caminhoCompleto.trim().isEmpty()) {
            throw new IOException("O caminho de destino do arquivo PDF não pode ser vazio.");
        }
        if (!caminhoCompleto.toLowerCase().endsWith(".pdf")) {
            caminhoCompleto += ".pdf";
        }

        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = null;

        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(caminhoCompleto));
            document.open();
            // ✅ CORRIGIDO: Linhas de atribuição "curso = """ e "turmaTurno = """ REMOVIDAS.
            // ✅ CORRIGIDO: Ordem dos argumentos ajustada para corresponder a gerarConteudoDaProva.
            gerarConteudoDaProva(document, questoesSelecionadas, disciplina, professor, dataProva, curso, turmaTurno);
        } catch (DocumentException | IOException e) {
            System.err.println("Erro ao salvar o arquivo PDF em: " + caminhoCompleto);
            e.printStackTrace();
            throw e;
        } finally {
            if (document.isOpen()) {
                document.close();
            }
        }
    }

    private void gerarConteudoDaProva(Document document, List<Questao> questoes,
                                      String disciplina, String professor, String dataProva,
                                      String curso, String turmaTurno)
            throws DocumentException {

        DateTimeFormatter formatoDesejado = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataFormatada;
        try {
            DateTimeFormatter formatoEntradaGUI = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate data = LocalDate.parse(dataProva, formatoEntradaGUI);
            dataFormatada = data.format(formatoDesejado);
        } catch (DateTimeParseException e) {
            try {
                LocalDate data = LocalDate.parse(dataProva, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                dataFormatada = data.format(formatoDesejado);
            } catch (DateTimeParseException e2) {
                dataFormatada = dataProva;
            }
        }

        Paragraph titulo = new Paragraph("AVALIAÇÃO", FONT_TITULO);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(10f);
        document.add(titulo);

        document.add(new Paragraph("Professor(a): " + professor, FONT_CABECALHO));
        document.add(new Paragraph("Data: " + dataFormatada, FONT_CABECALHO));
        document.add(Chunk.NEWLINE);

        PdfPTable infoAluno = new PdfPTable(2);
        infoAluno.setWidthPercentage(100);
        infoAluno.setWidths(new float[]{60, 40});

        infoAluno.getDefaultCell().setBorder(Rectangle.BOX);
        infoAluno.getDefaultCell().setPadding(5f);

        // O conteúdo aqui é o que garante a impressão
        infoAluno.addCell(createHeaderCell("Curso: " + (curso != null ? curso : " "), FONT_CABECALHO));
        infoAluno.addCell(createHeaderCell("Turma/Turno: " + (turmaTurno != null ? turmaTurno : " "), FONT_CABECALHO));

        infoAluno.addCell(createHeaderCell("Disciplina: " + (disciplina != null ? disciplina : " "), FONT_CABECALHO));
        infoAluno.addCell(createHeaderCell(" ", FONT_CABECALHO));

        PdfPCell nomeCell = createHeaderCell("Nome Completo: ", FONT_CABECALHO);
        nomeCell.setColspan(2);
        infoAluno.addCell(nomeCell);

        PdfPCell matriculaCell = createHeaderCell("Matrícula: ", FONT_CABECALHO);
        matriculaCell.setColspan(2);
        infoAluno.addCell(matriculaCell);

        document.add(infoAluno);
        document.add(Chunk.NEWLINE);

        Paragraph tituloGabaritoAluno = new Paragraph("GABARITO: Marque completamente o retângulo da alternativa correta, conforme o exemplo abaixo", FONT_CABECALHO);
        tituloGabaritoAluno.setSpacingBefore(10f);
        tituloGabaritoAluno.setSpacingAfter(5f);
        document.add(tituloGabaritoAluno);

        float larguraNumero = 0.20f;
        float larguraAlternativa = (1.00f - larguraNumero) / 5;
        float[] widths = new float[]{larguraNumero, larguraAlternativa, larguraAlternativa, larguraAlternativa, larguraAlternativa, larguraAlternativa};

        PdfPTable tableExemplo = new PdfPTable(widths);
        tableExemplo.setWidthPercentage(40);
        tableExemplo.setHorizontalAlignment(Element.ALIGN_LEFT);

        tableExemplo.addCell(createGabaritoCell("Nº", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("A", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("B", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("C", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("D", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("E", FONT_CABECALHO, true));

        tableExemplo.addCell(createGabaritoCell("Ex.", FONT_CABECALHO, false));

        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        PdfPCell cellPreenchida = new PdfPCell(new Phrase(" ", FONT_ALTERNATIVA));
        cellPreenchida.setHorizontalAlignment(Element.ALIGN_CENTER);
        cellPreenchida.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cellPreenchida.setFixedHeight(15f);
        cellPreenchida.setBackgroundColor(BaseColor.BLACK);
        cellPreenchida.setPadding(3f);
        tableExemplo.addCell(cellPreenchida);
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));

        document.add(tableExemplo);
        document.add(Chunk.NEWLINE);

        PdfPTable tableGabarito = new PdfPTable(widths);
        tableGabarito.setWidthPercentage(40);
        tableGabarito.setHorizontalAlignment(Element.ALIGN_LEFT);

        tableGabarito.addCell(createGabaritoCell("Nº", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("A", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("B", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("C", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("D", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("E", FONT_CABECALHO, true));

        for (int i = 1; i <= questoes.size(); i++) {
            tableGabarito.addCell(createGabaritoCell(String.valueOf(i), FONT_CABECALHO, false));
            for (int j = 0; j < 5; j++) {
                tableGabarito.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
            }
        }
        document.add(tableGabarito);
        document.add(new LineSeparator());
        document.add(Chunk.NEWLINE);

        int numQuestao = 1;
        for (Questao q : questoes) {
            Paragraph pEnunciado = new Paragraph(numQuestao + ". " + q.getEnunciado(), FONT_ENUNCIADO);
            pEnunciado.setSpacingAfter(5f);
            document.add(pEnunciado);

            char letra = 'A';
            for (Alternativa alt : q.getAlternativas()) {
                Paragraph pAlternativa = new Paragraph("    " + letra + ") " + alt.getTexto(), FONT_ALTERNATIVA);
                pAlternativa.setSpacingAfter(2f);
                document.add(pAlternativa);
                letra++;
            }
            document.add(Chunk.NEWLINE);
            numQuestao++;
        }
    }

    private PdfPCell createGabaritoCell(String text, Font font, boolean isHeader) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setFixedHeight(isHeader ? 18f : 15f);
        cell.setBackgroundColor(isHeader ? BaseColor.LIGHT_GRAY : BaseColor.WHITE);
        cell.setPhrase(new Phrase(text, font));
        cell.setPadding(2f);
        return cell;
    }

    private PdfPCell createHeaderCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setFixedHeight(25f);
        cell.setBorder(Rectangle.BOX);
        cell.setPadding(5f);
        return cell;
    }
}