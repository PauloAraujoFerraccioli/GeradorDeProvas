package com.geradorprovas.util;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class GeradorPDF {

    // Definição de Fontes
    private static final Font FONT_TITULO = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
    private static final Font FONT_CABECALHO = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_ENUNCIADO = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
    private static final Font FONT_ALTERNATIVA = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_MARCADOR = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);

    public GeradorPDF() { }

    /**
     * Ponto de entrada para a geração do documento PDF.
     */
    public void gerar(List<Questao> questoesSelecionadas, String disciplina,
                      String professor, String dataProva, String caminhoCompleto)
            throws DocumentException, IOException {

        if (caminhoCompleto == null || caminhoCompleto.trim().isEmpty()) {
            throw new IOException("O caminho de destino do arquivo PDF não pode ser vazio.");
        }
        if (!caminhoCompleto.toLowerCase().endsWith(".pdf")) {
            caminhoCompleto += ".pdf";
        }

        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = null;

        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(caminhoCompleto));
            document.open();
            gerarConteudoDaProva(document, questoesSelecionadas, disciplina, professor, dataProva);
        } catch (DocumentException | IOException e) {
            System.err.println("Erro ao salvar o arquivo PDF em: " + caminhoCompleto);
            e.printStackTrace();
            throw e;
        } finally {
            if (document.isOpen()) {
                document.close();
            }
        }
    }

    /**
     * Adiciona o cabeçalho, a área de gabarito do aluno e as questões no documento.
     */
    private void gerarConteudoDaProva(Document document, List<Questao> questoes,
                                      String disciplina, String professor, String dataProva)
            throws DocumentException {

        // --- 1. FORMATAÇÃO DA DATA ---
        DateTimeFormatter formatoEntrada = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatoDesejado = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataFormatada;
        try {
            LocalDate data = LocalDate.parse(dataProva, formatoEntrada);
            dataFormatada = data.format(formatoDesejado);
        } catch (DateTimeParseException e) {
            dataFormatada = dataProva;
        }

        // --- 2. CABEÇALHO ---
        Paragraph titulo = new Paragraph("PROVA DE " + disciplina.toUpperCase(), FONT_TITULO);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(10f);
        document.add(titulo);

        document.add(new Paragraph("Professor(a): " + professor, FONT_CABECALHO));
        document.add(new Paragraph("Data: " + dataFormatada, FONT_CABECALHO));
        document.add(Chunk.NEWLINE);

        // Campos do Aluno (Usando PdfPTable para a GRADE)
        PdfPTable infoAluno = new PdfPTable(2);
        infoAluno.setWidthPercentage(100);
        infoAluno.setWidths(new float[]{60, 40});

        // Configuração Padrão das Células (para ser sobrescrita)
        infoAluno.getDefaultCell().setBorder(Rectangle.BOX); // Define bordas para a grade
        infoAluno.getDefaultCell().setPadding(5f); // Aumenta o padding para melhor visualização

        // Linha 1: Curso e Turma/Turno
        // Removido o sublinhado e \n\n
        infoAluno.addCell(createHeaderCell("Curso: ", FONT_CABECALHO));
        infoAluno.addCell(createHeaderCell("Turma/Turno: ", FONT_CABECALHO));

        // Linha 2: Disciplina (e Célula Vazia)
        // Removido o sublinhado e \n\n
        infoAluno.addCell(createHeaderCell("Disciplina: ", FONT_CABECALHO));
        infoAluno.addCell(createHeaderCell(" ", FONT_CABECALHO)); // Célula vazia

        // Linha 3: Nome Completo (Linha inteira)
        // Uso de createHeaderCell e setColspan para a grade funcionar
        PdfPCell nomeCell = createHeaderCell("Nome Completo: ", FONT_CABECALHO);
        nomeCell.setColspan(2);
        infoAluno.addCell(nomeCell);

        // Linha 4: Matrícula (Linha inteira)
        // Uso de createHeaderCell
        PdfPCell matriculaCell = createHeaderCell("Matrícula: ", FONT_CABECALHO);
        matriculaCell.setColspan(2);
        infoAluno.addCell(matriculaCell);

        document.add(infoAluno);
        document.add(Chunk.NEWLINE);

        // ---------------------------------------------------------------------
        // --- 3. GABARITO (CAIXAS A-E) ---
        // ---------------------------------------------------------------------

        Paragraph tituloGabaritoAluno = new Paragraph("GABARITO: Marque completamente o retângulo da alternativa correta, conforme o exemplo abaixo", FONT_CABECALHO);
        tituloGabaritoAluno.setSpacingBefore(10f);
        tituloGabaritoAluno.setSpacingAfter(5f);
        document.add(tituloGabaritoAluno);

        // Define a proporção de largura para as colunas do gabarito.
        float larguraNumero = 0.20f;
        float larguraAlternativa = (1.00f - larguraNumero) / 5;
        float[] widths = new float[]{larguraNumero, larguraAlternativa, larguraAlternativa, larguraAlternativa, larguraAlternativa, larguraAlternativa};

        // --- 3A. LINHA DE EXEMPLO ---
        PdfPTable tableExemplo = new PdfPTable(widths);
        tableExemplo.setWidthPercentage(40);
        tableExemplo.setHorizontalAlignment(Element.ALIGN_LEFT);

        // Cabeçalho (Nº, A, B, C, D, E)
        tableExemplo.addCell(createGabaritoCell("Nº", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("A", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("B", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("C", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("D", FONT_CABECALHO, true));
        tableExemplo.addCell(createGabaritoCell("E", FONT_CABECALHO, true));

        // Linha de Exemplo (com "Ex." na primeira coluna)
        tableExemplo.addCell(createGabaritoCell("Ex.", FONT_CABECALHO, false));

        // Células de marcação do exemplo
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        PdfPCell cellPreenchida = new PdfPCell(new Phrase(" ", FONT_ALTERNATIVA));
        cellPreenchida.setHorizontalAlignment(Element.ALIGN_CENTER);
        cellPreenchida.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cellPreenchida.setFixedHeight(15f);
        cellPreenchida.setBackgroundColor(BaseColor.BLACK);
        cellPreenchida.setPadding(3f);
        tableExemplo.addCell(cellPreenchida);
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
        tableExemplo.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));

        document.add(tableExemplo);
        document.add(Chunk.NEWLINE);

        // --- 3B. TABELA DE GABARITO REAL ---

        PdfPTable tableGabarito = new PdfPTable(widths);
        tableGabarito.setWidthPercentage(40);
        tableGabarito.setHorizontalAlignment(Element.ALIGN_LEFT);

        // Cabeçalho Gabarito (Letras)
        tableGabarito.addCell(createGabaritoCell("Nº", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("A", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("B", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("C", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("D", FONT_CABECALHO, true));
        tableGabarito.addCell(createGabaritoCell("E", FONT_CABECALHO, true));


        // Linhas de Resposta Reais
        for (int i = 1; i <= questoes.size(); i++) {
            tableGabarito.addCell(createGabaritoCell(String.valueOf(i), FONT_CABECALHO, false));
            for (int j = 0; j < 5; j++) {
                tableGabarito.addCell(createGabaritoCell(" ", FONT_ALTERNATIVA, false));
            }
        }
        document.add(tableGabarito);
        document.add(new LineSeparator());
        document.add(Chunk.NEWLINE);

        // --- 4. CORPO DAS QUESTÕES (Numeração Automática) ---
        int numQuestao = 1;
        for (Questao q : questoes) {
            Paragraph pEnunciado = new Paragraph(numQuestao + ". " + q.getEnunciado(), FONT_ENUNCIADO);
            pEnunciado.setSpacingAfter(5f);
            document.add(pEnunciado);

            char letra = 'A';
            for (Alternativa alt : q.getAlternativas()) {
                Paragraph pAlternativa = new Paragraph("    " + letra + ") " + alt.getTexto(), FONT_ALTERNATIVA);
                pAlternativa.setSpacingAfter(2f);
                document.add(pAlternativa);
                letra++;
            }
            document.add(Chunk.NEWLINE);
            numQuestao++;
        }
    }

    /**
     * Cria uma célula para o gabarito.
     */
    private PdfPCell createGabaritoCell(String text, Font font, boolean isHeader) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setFixedHeight(isHeader ? 18f : 15f);
        cell.setBackgroundColor(isHeader ? BaseColor.LIGHT_GRAY : BaseColor.WHITE);
        cell.setPhrase(new Phrase(text, font));
        cell.setPadding(3f);
        return cell;
    }

    /**
     * NOVO MÉTODO: Cria uma célula com borda para o cabeçalho do aluno (grade).
     */
    private PdfPCell createHeaderCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setFixedHeight(25f); // Altura fixa para o campo
        cell.setBorder(Rectangle.BOX); // Define a borda (cria a grade)
        cell.setPadding(5f);
        return cell;
    }
}