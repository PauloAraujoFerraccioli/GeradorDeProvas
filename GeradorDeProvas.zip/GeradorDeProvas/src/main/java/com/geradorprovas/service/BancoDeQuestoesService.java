package com.geradorprovas.service;

import com.geradorprovas.dao.QuestaoDAO;
import com.geradorprovas.model.Questao;
import java.sql.SQLException;
import java.util.List;

public class BancoDeQuestoesService {

    private final QuestaoDAO questaoDAO;

    public BancoDeQuestoesService(QuestaoDAO questaoDAO) {
        // Assume que o QuestaoDAO é injetado e possui a lógica de acesso ao BD
        this.questaoDAO = questaoDAO;
    }

    /**
     * Busca todas as disciplinas únicas cadastradas.
     */
    public List<String> buscarDisciplinas() throws SQLException {
        return questaoDAO.buscarDisciplinas();
    }

    /**
     * Busca todas as questões de uma disciplina específica.
     */
    public List<Questao> buscarTodasQuestoesPorDisciplina(String disciplina) throws SQLException {
        if (disciplina == null || disciplina.trim().isEmpty()) {
            throw new IllegalArgumentException("A disciplina não pode ser vazia para a busca.");
        }
        // ✅ A chamada está correta:
        return questaoDAO.buscarTodasQuestoes(disciplina);
    }

    /**
     * Busca um número específico de questões aleatórias de uma disciplina.
     * (Usado pelo GerarProvaPanel)
     */
    public List<Questao> buscarQuestoesAleatorias(String disciplina, int quantidade) throws SQLException {
        if (disciplina == null || disciplina.trim().isEmpty() || quantidade <= 0) {
            throw new IllegalArgumentException("Disciplina e quantidade devem ser válidas para buscar questões aleatórias.");
        }
        // ✅ Chamada correta para o DAO, usando RAND() no SQL para MySQL.
        return questaoDAO.buscarQuestoesAleatorias(disciplina, quantidade);
    }

    /**
     * Cadastra uma nova questão no banco.
     */
    public void cadastrarQuestao(Questao questao) throws SQLException {
        // Uma validação mais completa da questão (enunciado, alternativas) poderia ser adicionada aqui.
        if (questao == null || questao.getEnunciado().trim().isEmpty()) {
            throw new IllegalArgumentException("A questão e seu enunciado não podem ser vazios.");
        }
        questaoDAO.cadastrarQuestao(questao);
    }

    /**
     * Atualiza uma questão existente.
     */
    public void atualizarQuestao(Questao questao) throws SQLException {
        // Validação verifica se o ID é nulo ou inválido
        if (questao == null || questao.getId() == null || questao.getId() <= 0) {
            throw new IllegalArgumentException("Questão inválida para atualização. ID ausente.");
        }
        questaoDAO.atualizarQuestao(questao);
    }

    /**
     * Exclui uma questão pelo seu ID.
     */
    public void excluirQuestao(Long Questao_id) throws SQLException {
        if (Questao_id == null || Questao_id <= 0) {
            throw new IllegalArgumentException("ID da questão inválido para exclusão.");
        }
        questaoDAO.excluirQuestao(Questao_id);
    }
}