package com.geradorprovas.service;

import com.geradorprovas.dao.QuestaoDAO;
import com.geradorprovas.model.Questao;
import com.geradorprovas.util.GeradorPDF;
import com.itextpdf.text.DocumentException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class BancoDeQuestoesService {

    private final QuestaoDAO questaoDAO;
    private final GeradorPDF geradorPDF;

    public BancoDeQuestoesService() {
        this.questaoDAO = new QuestaoDAO();
        this.geradorPDF = new GeradorPDF();
    }

    public BancoDeQuestoesService(QuestaoDAO questaoDAO) {
        this.questaoDAO = questaoDAO;
        this.geradorPDF = new GeradorPDF();
    }

    public void gerarProvaCompleta(String disciplina, int numQuestoes, String professor,
                                   String dataProva, String caminhoCompleto,
                                   String curso, String turmaTurno)
            throws SQLException, DocumentException, IOException {

        List<Questao> questoesSelecionadas = questaoDAO.buscarQuestoesAleatorias(disciplina, numQuestoes);

        if (questoesSelecionadas.isEmpty()) {
            System.err.println("Nenhuma questão encontrada para a disciplina: " + disciplina);
        }

        geradorPDF.gerar(curso, turmaTurno, questoesSelecionadas, disciplina, professor, dataProva, caminhoCompleto
        );
    }

    public List<String> buscarDisciplinas() throws SQLException {
        return questaoDAO.buscarDisciplinas();
    }

    public List<Questao> buscarTodasQuestoesPorDisciplina(String disciplina) throws SQLException {
        if (disciplina == null || disciplina.trim().isEmpty()) {
            throw new IllegalArgumentException("A disciplina não pode ser vazia para a busca.");
        }
        return questaoDAO.buscarTodasQuestoes(disciplina);
    }

    public List<Questao> buscarQuestoesAleatorias(String disciplina, int quantidade) throws SQLException {
        if (disciplina == null || disciplina.trim().isEmpty() || quantidade <= 0) {
            throw new IllegalArgumentException("Disciplina e quantidade devem ser válidas para buscar questões aleatórias.");
        }
        return questaoDAO.buscarQuestoesAleatorias(disciplina, quantidade);
    }

    public void cadastrarQuestao(Questao questao) throws SQLException {
        if (questao == null || questao.getEnunciado().trim().isEmpty()) {
            throw new IllegalArgumentException("A questão e seu enunciado não podem ser vazios.");
        }
        questaoDAO.cadastrarQuestao(questao);
    }

    public void atualizarQuestao(Questao questao) throws SQLException {
        if (questao == null || questao.getId() == null || questao.getId() <= 0) {
            throw new IllegalArgumentException("Questão inválida para atualização. ID ausente.");
        }
        questaoDAO.atualizarQuestao(questao);
    }

    public void excluirQuestao(Long questao_id) throws SQLException {
        if (questao_id == null || questao_id <= 0) {
            throw new IllegalArgumentException("ID da questão inválido para exclusão.");
        }
        questaoDAO.excluirQuestao(questao_id);
    }
}