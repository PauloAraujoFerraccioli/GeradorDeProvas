package com.geradorprovas.model;

import java.util.ArrayList;
import java.util.List;

public class Questao {

    private Long id; // ID no banco de dados (nulo se for nova)
    private String enunciado;
    private String disciplina;
    private List<Alternativa> alternativas;

    // Construtor usado no cadastro
    public Questao(String enunciado, String disciplina, List<Alternativa> alternativas) {
        this.enunciado = enunciado;
        this.disciplina = disciplina;
        this.alternativas = alternativas;
    }

    // Construtor usado na listagem (DAO)
    public Questao() {
        this.alternativas = new ArrayList<>();
    }

    // Construtor especial usado para itens de aviso em JComboBoxes
    public Questao(String enunciado, String disciplina) {
        this.enunciado = enunciado;
        this.disciplina = disciplina;
        // Inicializa a lista para evitar NullPointerException mais tarde
        this.alternativas = new ArrayList<>();
    }
    public void adicionarAlternativa(Alternativa alternativa) {
        if (this.alternativas == null) {
            this.alternativas = new ArrayList<>();
        }
        this.alternativas.add(alternativa);
    }
    // --- MÉTODOS ESSENCIAIS ---

    /**
     * Sobrescreve o método toString para formatar a exibição no JComboBox.
     */
    @Override
    public String toString() {
        // Exibe o ID (se existir) e um trecho do enunciado
        String prefix = (id != null) ? "Q" + id + ": " : "";

        // Trunca o enunciado para 50 caracteres para não estourar o JComboBox
        String trechoEnunciado = enunciado;
        if (enunciado != null && enunciado.length() > 50) {
            trechoEnunciado = enunciado.substring(0, 50).trim() + "...";
        } else if (enunciado == null) {
            trechoEnunciado = "Sem Enunciado";
        }

        return prefix + trechoEnunciado;
    }

    // --- Getters e Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public List<Alternativa> getAlternativas() {
        return alternativas;
    }

    public void setAlternativas(List<Alternativa> alternativas) {
        this.alternativas = alternativas;
    }
}