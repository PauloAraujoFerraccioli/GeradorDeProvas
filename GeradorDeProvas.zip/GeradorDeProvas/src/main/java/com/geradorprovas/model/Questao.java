package com.geradorprovas.model;

import java.util.ArrayList;
import java.util.List;

public class Questao {

    private Long id;
    private String enunciado;
    private String disciplina;
    private List<Alternativa> alternativas;

    // 1. Construtor Vazio
    public Questao() {
    }

    // 2. Construtor (String, String)
    public Questao(String enunciado, String disciplina) {
        this.enunciado = enunciado;
        this.disciplina = disciplina;
    }

    // 3. Construtor Completo
    public Questao(Long id, String enunciado, String disciplina, List<Alternativa> alternativas) {
        this.id = id;
        this.enunciado = enunciado;
        this.disciplina = disciplina;
        this.alternativas = alternativas;
    }

    /**
     * ✅ MÉTODO ADICIONADO: Permite adicionar uma alternativa de cada vez.
     * Resolve o erro 'cannot find symbol: method adicionarAlternativa'.
     */
    public void adicionarAlternativa(Alternativa alternativa) {
        if (this.alternativas == null) {
            this.alternativas = new ArrayList<>();
        }
        this.alternativas.add(alternativa);
    }

    // --- Getters e Setters (Mantenha todos) ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEnunciado() { return enunciado; }
    public void setEnunciado(String enunciado) { this.enunciado = enunciado; }

    public String getDisciplina() { return disciplina; }
    public void setDisciplina(String disciplina) { this.disciplina = disciplina; }

    public List<Alternativa> getAlternativas() { return alternativas; }
    public void setAlternativas(List<Alternativa> alternativas) { this.alternativas = alternativas; }
}