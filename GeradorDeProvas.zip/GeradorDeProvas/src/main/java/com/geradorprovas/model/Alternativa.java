package com.geradorprovas.model;

public class Alternativa {

    private Long id; // ID no banco de dados (nulo se for nova)
    private String texto;
    private boolean correta;

    // Construtor completo (usado ao carregar do banco de dados/atualizar)
    public Alternativa(Long id, String texto, boolean correta) {
        this.id = id;
        this.texto = texto;
        this.correta = correta;
    }

    // Construtor usado no cadastro (id ainda não definido)
    public Alternativa(String texto, boolean correta) {
        this(null, texto, correta);
    }

    // Construtor padrão (pode ser útil para frameworks ou deserialização)
    public Alternativa() {
    }

    // --- Getters e Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public boolean isCorreta() {
        return correta;
    }

    public void setCorreta(boolean correta) {
        this.correta = correta;
    }
}