package com.geradorprovas.model;

public class Alternativa {

    private Long id;
    private String texto;
    private boolean correta;

    public Alternativa(Long id, String texto, boolean correta) {
        this.id = id;
        this.texto = texto;
        this.correta = correta;
    }

    // Construtor usado no cadastro
    public Alternativa(String texto, boolean correta) {
        this(null, texto, correta);
    }

    // Construtor padrão
    public Alternativa() {
    }

    // --- Getters e Setters ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public boolean isCorreta() {
        return correta;
    }

    public void setCorreta(boolean correta) {
        this.correta = correta;
    }
}