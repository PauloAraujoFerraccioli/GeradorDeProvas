package com.geradorprovas.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexao {

    private static final String HOST = "127.0.0.1";
    private static final String NOME_BANCO = "db-questoesdasprovas";

    // ATENÇÃO: Confirme a sua senha resolvida aqui!
    private static final String USER = "root";
    private static final String PASS = "W1i9r8e4**Eliseu"; // Insira sua senha
    private static final String PORT = "3306";

    private static final String URL_PARAMS = "?serverTimezone=UTC";
    private static final String URL_SERVER_ONLY = "jdbc:mysql://" + HOST + ":" + PORT + URL_PARAMS;
    private static final String URL_COMPLETA = "jdbc:mysql://" + HOST + ":" + PORT + "/" + NOME_BANCO + URL_PARAMS;


    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 1. Tenta a conexão COMPLETA
            Connection conn = DriverManager.getConnection(URL_COMPLETA, USER, PASS);

            // 2. Cria a estrutura das tabelas (se ainda não existirem)
            criarEstruturaBanco(conn);

            return conn;

        } catch (ClassNotFoundException e) {
            System.err.println("Erro Crítico: Driver JDBC do MySQL não encontrado.");
            throw new SQLException("Erro ao carregar o Driver JDBC do MySQL.", e);
        } catch (SQLException e) {

            // 3. SE FALHAR por "Unknown database" (banco não existe)
            if (e.getMessage().contains("Unknown database")) {
                System.out.println("Banco de dados '" + NOME_BANCO + "' não encontrado. Criando e reconectando...");

                try (Connection conn = DriverManager.getConnection(URL_SERVER_ONLY, USER, PASS);
                     Statement stmt = conn.createStatement()) {

                    // CRIA O BANCO DE DADOS
                    stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + NOME_BANCO + "`");

                    // Tenta a conexão completa novamente
                    Connection novaConn = DriverManager.getConnection(URL_COMPLETA, USER, PASS);

                    // CRIA AS TABELAS NO NOVO BANCO DE DADOS
                    criarEstruturaBanco(novaConn);

                    return novaConn;

                } catch (SQLException createDbError) {
                    System.err.println("Erro ao tentar criar o banco de dados ou a estrutura de tabelas.");
                    throw createDbError;
                }
            }

            // 4. Se for qualquer outro erro, lança o original
            System.err.println("--- FALHA NA CONEXÃO OU AUTENTICAÇÃO ---");
            System.err.println("Detalhe do Erro: " + e.getMessage());
            throw e;
        }
    }

    private static void criarEstruturaBanco(Connection conn) throws SQLException {
        // SQL com "IF NOT EXISTS" para que o código seja executado apenas uma vez.
        String sqlQuestoes = "CREATE TABLE IF NOT EXISTS questoes ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "enunciado TEXT NOT NULL,"
                + "disciplina VARCHAR(100) NOT NULL"
                + ")";

        String sqlAlternativas = "CREATE TABLE IF NOT EXISTS alternativas ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "questao_id INT NOT NULL,"
                + "texto TEXT NOT NULL,"
                + "correta BOOLEAN NOT NULL,"
                + "FOREIGN KEY (questao_id) REFERENCES questoes(id) ON DELETE CASCADE"
                + ")";

        try (Statement stmt = conn.createStatement()) {
            // Cria a tabela de Questões
            stmt.executeUpdate(sqlQuestoes);
            // Cria a tabela de Alternativas (que depende de Questões)
            stmt.executeUpdate(sqlAlternativas);
            System.out.println("Estrutura do banco de dados verificada/criada com sucesso.");
        }
    }

    // Métodos closeConnection permanecem inalterados
    public static void closeConnection(Connection conn) {
        // ... (código closeConnection)
    }

    public static void closeConnection(Connection conn, Statement stmt, ResultSet rs) {
        // ... (código closeConnection)
    }
}