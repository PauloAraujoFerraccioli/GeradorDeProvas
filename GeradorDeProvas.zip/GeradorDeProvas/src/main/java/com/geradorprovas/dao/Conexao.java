package com.geradorprovas.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    // ⚠️ ATENÇÃO: Credenciais configuradas para o banco 'db-questoesdasprovas' ⚠️
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    // URL com nome do banco de dados e fuso horário para compatibilidade
    private static final String URL = "jdbc:mysql://localhost:3306/db-questoesdasprovas?serverTimezone=UTC";
    private static final String USUARIO = "root";
    private static final String SENHA = "W1i9r8e4**Eliseu"; // Senha fornecida

    /**
     * Estabelece e retorna uma nova conexão com o banco de dados.
     * @return Objeto Connection.
     * @throws SQLException Se a conexão falhar (credenciais, driver ou URL inválidos).
     */
    public static Connection getConnection() throws SQLException {
        try {
            // 1. Carrega o driver JDBC
            Class.forName(DRIVER);

            // 2. Tenta estabelecer a conexão
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            // Lança uma exceção se o JAR do driver (Connector/J) não estiver no classpath
            throw new SQLException("Driver JDBC não encontrado. Certifique-se de que o MySQL Connector/J .jar está no classpath.", e);
        }
    }

    /**
     * Método auxiliar para fechar a conexão de forma segura.
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Erro ao fechar a conexão: " + e.getMessage());
            }
        }
    }
}