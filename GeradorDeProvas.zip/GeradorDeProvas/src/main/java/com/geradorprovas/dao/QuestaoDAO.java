package com.geradorprovas.dao;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestaoDAO {

    public void salvarQuestao(Questao questao) throws SQLException {
        Connection conn = null;
        PreparedStatement psQuestao = null;

        try {
            conn = Conexao.getConnection();
            conn.setAutoCommit(false); // Inicia a transação

            String sqlQuestao = "INSERT INTO questoes (enunciado, disciplina) VALUES (?, ?)";

            psQuestao = conn.prepareStatement(sqlQuestao, Statement.RETURN_GENERATED_KEYS);
            psQuestao.setString(1, questao.getEnunciado());
            psQuestao.setString(2, questao.getDisciplina());
            psQuestao.executeUpdate();

            try (ResultSet rs = psQuestao.getGeneratedKeys()) {
                if (rs.next()) {
                    long idQuestao = rs.getLong(1);
                    questao.setId(idQuestao);

                    salvarAlternativas(conn, questao);
                }
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            Conexao.closeConnection(conn, psQuestao, null);
        }
    }

    private void salvarAlternativas(Connection conn, Questao questao) throws SQLException {
        String sqlAlternativa = "INSERT INTO alternativas (questao_id, texto, correta) VALUES (?, ?, ?)";
        try (PreparedStatement psAlternativa = conn.prepareStatement(sqlAlternativa)) {
            for (Alternativa alt : questao.getAlternativas()) {
                psAlternativa.setLong(1, questao.getId());
                psAlternativa.setString(2, alt.getTexto());
                psAlternativa.setBoolean(3, alt.isCorreta());
                psAlternativa.addBatch();
            }
            psAlternativa.executeBatch();
        }
    }

    /**
     * Busca todas as questões COMPLETAS (com suas alternativas) e as agrupa por disciplina.
     * @return Um mapa onde a chave é a disciplina e o valor é a lista de Questões.
     */
    public Map<String, List<Questao>> agruparQuestoesPorDisciplina() throws SQLException {
        Map<Long, Questao> questoesMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = "SELECT q.id AS questao_id, q.enunciado, q.disciplina, "
                + "a.id AS alternativa_id, a.texto, a.correta "
                + "FROM questoes q LEFT JOIN alternativas a ON q.id = a.questao_id "
                + "ORDER BY q.disciplina, q.id, a.id";

        try {
            conn = Conexao.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Long questaoId = rs.getLong("questao_id");

                Questao questao = questoesMap.get(questaoId);
                if (questao == null) {
                    questao = new Questao();
                    questao.setId(questaoId);
                    questao.setEnunciado(rs.getString("enunciado"));
                    questao.setDisciplina(rs.getString("disciplina"));
                    questao.setAlternativas(new ArrayList<>());
                    questoesMap.put(questaoId, questao);
                }

                Long alternativaId = rs.getLong("alternativa_id");
                if (alternativaId > 0) {
                    Alternativa alt = new Alternativa();
                    alt.setId(alternativaId);
                    alt.setTexto(rs.getString("texto"));
                    alt.setCorreta(rs.getBoolean("correta"));
                    questao.getAlternativas().add(alt);
                }
            }

            Map<String, List<Questao>> resultado = new HashMap<>();
            for (Questao q : questoesMap.values()) {
                resultado.computeIfAbsent(q.getDisciplina(), k -> new ArrayList<>()).add(q);
            }

            return resultado;
        } finally {
            Conexao.closeConnection(conn, ps, rs);
        }
    }

    public void atualizarQuestao(Questao questao) throws SQLException {
        Connection conn = null;
        PreparedStatement psQuestao = null;

        try {
            conn = Conexao.getConnection();
            conn.setAutoCommit(false);

            String sqlQuestao = "UPDATE questoes SET enunciado = ?, disciplina = ? WHERE id = ?";
            psQuestao = conn.prepareStatement(sqlQuestao);

            psQuestao.setString(1, questao.getEnunciado());
            psQuestao.setString(2, questao.getDisciplina());
            psQuestao.setLong(3, questao.getId());
            psQuestao.executeUpdate();

            sincronizarAlternativas(conn, questao);

            conn.commit();

        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            Conexao.closeConnection(conn, psQuestao, null);
        }
    }

    private void sincronizarAlternativas(Connection conn, Questao questao) throws SQLException {

        List<Long> idsAtuais = new ArrayList<>();

        String sqlInsert = "INSERT INTO alternativas (questao_id, texto, correta) VALUES (?, ?, ?)";
        String sqlUpdate = "UPDATE alternativas SET texto = ?, correta = ? WHERE id = ?";

        try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {

            for (Alternativa alt : questao.getAlternativas()) {
                if (alt.getId() == null) {
                    psInsert.setLong(1, questao.getId());
                    psInsert.setString(2, alt.getTexto());
                    psInsert.setBoolean(3, alt.isCorreta());
                    psInsert.addBatch();

                } else {
                    psUpdate.setString(1, alt.getTexto());
                    psUpdate.setBoolean(2, alt.isCorreta());
                    psUpdate.setLong(3, alt.getId());
                    psUpdate.addBatch();

                    idsAtuais.add(alt.getId());
                }
            }
            psInsert.executeBatch();
            psUpdate.executeBatch();
        }

        if (idsAtuais.isEmpty()) {
            String sqlDeleteAll = "DELETE FROM alternativas WHERE questao_id = ?";
            try (PreparedStatement psDeleteAll = conn.prepareStatement(sqlDeleteAll)) {
                psDeleteAll.setLong(1, questao.getId());
                psDeleteAll.executeUpdate();
            }
        }
        else {
            StringBuilder placeholders = new StringBuilder();
            for (int i = 0; i < idsAtuais.size(); i++) {
                placeholders.append("?");
                if (i < idsAtuais.size() - 1) {
                    placeholders.append(", ");
                }
            }

            String sqlDelete = "DELETE FROM alternativas WHERE questao_id = ? AND id NOT IN (" + placeholders.toString() + ")";
            try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {

                int paramIndex = 1;
                psDelete.setLong(paramIndex++, questao.getId());

                for (Long id : idsAtuais) {
                    psDelete.setLong(paramIndex++, id);
                }
                psDelete.executeUpdate();
            }
        }
    }

    public void excluirQuestao(Long idQuestao) throws SQLException {
        String sql = "DELETE FROM questoes WHERE id = ?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Conexao.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, idQuestao);
            ps.executeUpdate();
        } finally {
            Conexao.closeConnection(conn, ps, null);
        }
    }

    /**
     * Busca um número específico de questões aleatórias de uma dada disciplina, completas com alternativas.
     */
    public List<Questao> buscarQuestoesAleatorias(String disciplina, int limite) throws SQLException {
        Map<String, List<Questao>> questoesPorDisciplina = agruparQuestoesPorDisciplina();
        List<Questao> todasDaDisciplina = questoesPorDisciplina.getOrDefault(disciplina, Collections.emptyList());
        if (todasDaDisciplina.isEmpty()) {
            return Collections.emptyList();
        }

        Collections.shuffle(todasDaDisciplina);

        return todasDaDisciplina.subList(0, Math.min(limite, todasDaDisciplina.size()));
    }

    public List<Questao> buscarTodas() {
        return List.of();
    }

    public void salvar(Questao questao) {
    }

    public List<String> buscarDisciplinas() {
        return List.of();
    }
}