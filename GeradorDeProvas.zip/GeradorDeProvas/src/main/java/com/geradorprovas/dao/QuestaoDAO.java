package com.geradorprovas.dao;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import com.geradorprovas.util.Conexao; // Presume-se que Conexao gerencia a conexão e fecha no final
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestaoDAO {

    // --- Helpers para Criação de Objetos ---
    private Questao criarQuestaoComAlternativas(ResultSet rs) throws SQLException {
        Questao q = new Questao();
        Long id = rs.getLong("id");
        q.setId(id);
        q.setEnunciado(rs.getString("enunciado"));
        q.setDisciplina(rs.getString("disciplina"));
        // Chama o método auxiliar para buscar as alternativas
        q.setAlternativas(buscarAlternativasPorQuestao(id));
        return q;
    }

    private List<Alternativa> buscarAlternativasPorQuestao(Long questaoId) throws SQLException {
        List<Alternativa> alternativas = new ArrayList<>();
        // Colunas: id, texto, correta | FK: questao_id
        String sql = "SELECT id, texto, correta FROM alternativa WHERE questao_id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, questaoId);
            try(ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Alternativa a = new Alternativa();
                    a.setId(rs.getLong("id"));
                    a.setTexto(rs.getString("texto"));
                    a.setCorreta(rs.getBoolean("correta"));
                    alternativas.add(a);
                }
            }
        }
        return alternativas;
    }

    private void atualizarAlternativas(Connection conn, Long questaoId, List<Alternativa> alternativas) throws SQLException {
        // CORREÇÃO AQUI: Usando 'questao_id' em vez de 'id_questao'
        String sqlDelete = "DELETE FROM alternativa WHERE questao_id = ?";
        try (PreparedStatement stmtDelete = conn.prepareStatement(sqlDelete)) {
            stmtDelete.setLong(1, questaoId);
            stmtDelete.executeUpdate();
        }

        String sqlInsert = "INSERT INTO alternativa (questao_id, texto, correta) VALUES (?, ?, ?)";
        try (PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert)) {
            for (Alternativa alt : alternativas) {
                stmtInsert.setLong(1, questaoId);
                stmtInsert.setString(2, alt.getTexto());
                stmtInsert.setBoolean(3, alt.isCorreta());
                stmtInsert.addBatch();
            }
            stmtInsert.executeBatch();
        }
    }

    // --- Métodos de Busca e Listagem ---

    public List<String> buscarDisciplinas() throws SQLException {
        List<String> disciplinas = new ArrayList<>();
        String sql = "SELECT DISTINCT disciplina FROM questao ORDER BY disciplina";

        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                disciplinas.add(rs.getString("disciplina"));
            }
        }
        return disciplinas;
    }

    public List<Questao> buscarTodasQuestoes(String disciplina) throws SQLException {
        List<Questao> questoes = new ArrayList<>();
        // Adicionada a cláusula WHERE para filtrar por disciplina, senão buscaria todas as disciplinas
        String sql = "SELECT id, enunciado, disciplina FROM questao WHERE disciplina = ? ORDER BY id";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, disciplina); // Define o filtro da disciplina

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Questao q = criarQuestaoComAlternativas(rs);
                    questoes.add(q);
                }
            }
        }
        return questoes;
    }

    /**
     * Busca um número específico de questões aleatórias.
     */
    public List<Questao> buscarQuestoesAleatorias(String disciplina, int quantidade) throws SQLException {
        List<Questao> questoes = new ArrayList<>();

        String sql = "SELECT id, enunciado, disciplina FROM questao "
                + "WHERE disciplina = ? "
                + "ORDER BY RAND() "
                + "LIMIT ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, disciplina);
            stmt.setInt(2, quantidade);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Questao q = criarQuestaoComAlternativas(rs);
                    questoes.add(q);
                }
            }
        }
        return questoes;
    }

    // --- Métodos de Escrita (Transacionais/CRUD) ---

    public void cadastrarQuestao(Questao questao) throws SQLException {
        String sqlQuestao = "INSERT INTO questao (enunciado, disciplina) VALUES (?, ?)";
        String sqlAlternativa = "INSERT INTO alternativa (questao_id, texto, correta) VALUES (?, ?, ?)";

        try (Connection conn = Conexao.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtQuestao = conn.prepareStatement(sqlQuestao, Statement.RETURN_GENERATED_KEYS)) {
                stmtQuestao.setString(1, questao.getEnunciado());
                stmtQuestao.setString(2, questao.getDisciplina());
                stmtQuestao.executeUpdate();

                try (ResultSet rs = stmtQuestao.getGeneratedKeys()) {
                    if (rs.next()) {
                        Long questaoId = rs.getLong(1);
                        questao.setId(questaoId); // Define o ID gerado no objeto

                        try (PreparedStatement stmtAlternativa = conn.prepareStatement(sqlAlternativa)) {
                            for (Alternativa alt : questao.getAlternativas()) {
                                stmtAlternativa.setLong(1, questaoId);
                                stmtAlternativa.setString(2, alt.getTexto());
                                stmtAlternativa.setBoolean(3, alt.isCorreta());
                                stmtAlternativa.addBatch();
                            }
                            stmtAlternativa.executeBatch();
                        }
                    } else {
                        throw new SQLException("Falha ao obter ID da Questão após inserção.");
                    }
                }
            }
            conn.commit();
        } catch (SQLException e) {
            // Não é necessário o throw e; se você já usa throws SQLException no método
            try {
                if (Conexao.getConnection() != null) Conexao.getConnection().rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro durante rollback: " + rollbackEx.getMessage());
            }
            throw new SQLException("Erro ao cadastrar questão.", e);
        }
    }

    public void atualizarQuestao(Questao questao) throws SQLException {
        String sqlQuestao = "UPDATE questao SET enunciado = ?, disciplina = ? WHERE id = ?";

        try (Connection conn = Conexao.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtQuestao = conn.prepareStatement(sqlQuestao)) {
                stmtQuestao.setString(1, questao.getEnunciado());
                stmtQuestao.setString(2, questao.getDisciplina());
                stmtQuestao.setLong(3, questao.getId());
                stmtQuestao.executeUpdate();
            }

            // Atualiza as alternativas (deleta as antigas e insere as novas)
            atualizarAlternativas(conn, questao.getId(), questao.getAlternativas());

            conn.commit();

        } catch (SQLException e) {
            try {
                if (Conexao.getConnection() != null) Conexao.getConnection().rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro durante rollback: " + rollbackEx.getMessage());
            }
            throw new SQLException("Erro ao atualizar questão.", e);
        }
    }

    public void excluirQuestao(Long questaoId) throws SQLException {
        // O DELETE deve ser feito na ordem de chave estrangeira: primeiro as alternativas, depois a questão
        String sqlAlternativas = "DELETE FROM alternativa WHERE questao_id = ?";
        // CORREÇÃO AQUI: A tabela 'questao' deve ser excluída pelo seu próprio 'id'
        String sqlQuestao = "DELETE FROM questao WHERE id = ?";

        try (Connection conn = Conexao.getConnection()) {
            conn.setAutoCommit(false);

            // 1. Excluir Alternativas
            try (PreparedStatement stmtAlternativas = conn.prepareStatement(sqlAlternativas)) {
                stmtAlternativas.setLong(1, questaoId);
                stmtAlternativas.executeUpdate();
            }

            // 2. Excluir Questão
            try (PreparedStatement stmtQuestao = conn.prepareStatement(sqlQuestao)) {
                stmtQuestao.setLong(1, questaoId);
                stmtQuestao.executeUpdate();
            }

            conn.commit();

        } catch (SQLException e) {
            try {
                if (Conexao.getConnection() != null) Conexao.getConnection().rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro durante rollback: " + rollbackEx.getMessage());
            }
            throw new SQLException("Erro ao excluir questão.", e);
        }
    }
}