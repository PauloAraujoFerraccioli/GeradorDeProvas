package com.geradorprovas.dao;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestaoDAO {

    // --- 1. SALVAR (CADASTRO) ---

    public void salvarQuestao(Questao questao) throws SQLException {
        Connection conn = null;
        PreparedStatement psQuestao = null;

        try {
            conn = Conexao.getConnection();
            conn.setAutoCommit(false); // Inicia a transação

            // SQL para a tabela 'questoes'
            String sqlQuestao = "INSERT INTO questoes (enunciado, disciplina) VALUES (?, ?)";

            // Statement.RETURN_GENERATED_KEYS é crucial para obter o ID gerado
            psQuestao = conn.prepareStatement(sqlQuestao, Statement.RETURN_GENERATED_KEYS);
            psQuestao.setString(1, questao.getEnunciado());
            psQuestao.setString(2, questao.getDisciplina());
            psQuestao.executeUpdate();

            // 1.1. Recupera o ID gerado para a Questão
            try (ResultSet rs = psQuestao.getGeneratedKeys()) {
                if (rs.next()) {
                    long idQuestao = rs.getLong(1);
                    questao.setId(idQuestao); // Define o ID no objeto

                    // 1.2. Salva as alternativas usando o ID da questão
                    salvarAlternativas(conn, questao);
                }
            }

            conn.commit(); // Confirma a transação
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Desfaz a transação em caso de erro
            }
            throw e;
        } finally {
            Conexao.closeConnection(conn, psQuestao, null);
        }
    }

    private void salvarAlternativas(Connection conn, Questao questao) throws SQLException {
        String sqlAlternativa = "INSERT INTO alternativas (questao_id, texto, correta) VALUES (?, ?, ?)";
        try (PreparedStatement psAlternativa = conn.prepareStatement(sqlAlternativa)) {
            for (Alternativa alt : questao.getAlternativas()) {
                psAlternativa.setLong(1, questao.getId());
                psAlternativa.setString(2, alt.getTexto());
                psAlternativa.setBoolean(3, alt.isCorreta());
                psAlternativa.addBatch(); // Adiciona ao lote para execução eficiente
            }
            psAlternativa.executeBatch(); // Executa todas as inserções
        }
    }

    // --- 2. AGRUPAR (LISTAGEM/EDIÇÃO) ---

    /**
     * Busca todas as questões COMPLETAS (com suas alternativas) e as agrupa por disciplina.
     * @return Um mapa onde a chave é a disciplina e o valor é a lista de Questões.
     */
    public Map<String, List<Questao>> agruparQuestoesPorDisciplina() throws SQLException {
        Map<Long, Questao> questoesMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        // Junta as tabelas para buscar questões e alternativas em uma única consulta
        String sql = "SELECT q.id AS questao_id, q.enunciado, q.disciplina, "
                + "a.id AS alternativa_id, a.texto, a.correta "
                + "FROM questoes q LEFT JOIN alternativas a ON q.id = a.questao_id "
                + "ORDER BY q.disciplina, q.id, a.id";

        try {
            conn = Conexao.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Long questaoId = rs.getLong("questao_id");

                // Cria ou recupera o objeto Questao
                Questao questao = questoesMap.get(questaoId);
                if (questao == null) {
                    questao = new Questao();
                    questao.setId(questaoId);
                    questao.setEnunciado(rs.getString("enunciado"));
                    questao.setDisciplina(rs.getString("disciplina"));
                    questao.setAlternativas(new ArrayList<>());
                    questoesMap.put(questaoId, questao);
                }

                // Adiciona a alternativa, se existir (LEFT JOIN)
                Long alternativaId = rs.getLong("alternativa_id");
                if (alternativaId > 0) {
                    Alternativa alt = new Alternativa();
                    alt.setId(alternativaId);
                    alt.setTexto(rs.getString("texto"));
                    alt.setCorreta(rs.getBoolean("correta"));
                    questao.getAlternativas().add(alt);
                }
            }

            // Agrupa as questões completas por disciplina
            Map<String, List<Questao>> resultado = new HashMap<>();
            for (Questao q : questoesMap.values()) {
                resultado.computeIfAbsent(q.getDisciplina(), k -> new ArrayList<>()).add(q);
            }

            return resultado;
        } finally {
            Conexao.closeConnection(conn, ps, rs);
        }
    }

    // --- 3. ATUALIZAR (EDIÇÃO) ---

    public void atualizarQuestao(Questao questao) throws SQLException {
        Connection conn = null;
        PreparedStatement psQuestao = null;

        try {
            conn = Conexao.getConnection();
            conn.setAutoCommit(false); // Inicia a transação

            // 1. ATUALIZAÇÃO DO ENUNCIADO E DISCIPLINA
            String sqlQuestao = "UPDATE questoes SET enunciado = ?, disciplina = ? WHERE id = ?";
            psQuestao = conn.prepareStatement(sqlQuestao);

            psQuestao.setString(1, questao.getEnunciado());
            psQuestao.setString(2, questao.getDisciplina());
            psQuestao.setLong(3, questao.getId());
            psQuestao.executeUpdate();

            // 2. ATUALIZAÇÃO / INSERÇÃO / EXCLUSÃO DAS ALTERNATIVAS
            sincronizarAlternativas(conn, questao);

            conn.commit(); // Confirma a transação

        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Desfaz em caso de erro
            }
            throw e;
        } finally {
            Conexao.closeConnection(conn, psQuestao, null);
        }
    }

    private void sincronizarAlternativas(Connection conn, Questao questao) throws SQLException {

        List<Long> idsAtuais = new ArrayList<>();

        String sqlInsert = "INSERT INTO alternativas (questao_id, texto, correta) VALUES (?, ?, ?)";
        String sqlUpdate = "UPDATE alternativas SET texto = ?, correta = ? WHERE id = ?";

        try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {

            for (Alternativa alt : questao.getAlternativas()) {
                if (alt.getId() == null) {
                    // SE FOR NOVA (ID é null): INSERIR
                    psInsert.setLong(1, questao.getId());
                    psInsert.setString(2, alt.getTexto());
                    psInsert.setBoolean(3, alt.isCorreta());
                    psInsert.addBatch();

                } else {
                    // SE JÁ EXISTE: ATUALIZAR
                    psUpdate.setString(1, alt.getTexto());
                    psUpdate.setBoolean(2, alt.isCorreta());
                    psUpdate.setLong(3, alt.getId());
                    psUpdate.addBatch();

                    idsAtuais.add(alt.getId());
                }
            }
            psInsert.executeBatch();
            psUpdate.executeBatch();
        }

        // 3. EXCLUSÃO DAS ALTERNATIVAS REMOVIDAS
        if (idsAtuais.isEmpty()) {
            // Caso todas as alternativas tenham sido removidas (lista vazia)
            String sqlDeleteAll = "DELETE FROM alternativas WHERE questao_id = ?";
            try (PreparedStatement psDeleteAll = conn.prepareStatement(sqlDeleteAll)) {
                psDeleteAll.setLong(1, questao.getId());
                psDeleteAll.executeUpdate();
            }
        }
        else {
            // Deleta todas as alternativas da questão que NÃO estão na lista 'idsAtuais'
            StringBuilder placeholders = new StringBuilder();
            for (int i = 0; i < idsAtuais.size(); i++) {
                placeholders.append("?");
                if (i < idsAtuais.size() - 1) {
                    placeholders.append(", ");
                }
            }

            String sqlDelete = "DELETE FROM alternativas WHERE questao_id = ? AND id NOT IN (" + placeholders.toString() + ")";
            try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {

                int paramIndex = 1;
                psDelete.setLong(paramIndex++, questao.getId()); // questao_id é o primeiro

                for (Long id : idsAtuais) {
                    psDelete.setLong(paramIndex++, id); // IDs para manter (NOT IN)
                }
                psDelete.executeUpdate();
            }
        }
    }

    // --- 4. EXCLUIR (EXCLUSÃO) ---

    public void excluirQuestao(Long idQuestao) throws SQLException {
        // Devido ao 'ON DELETE CASCADE' na tabela 'alternativas',
        // apenas deletar a questão deve ser suficiente para apagar suas alternativas.
        String sql = "DELETE FROM questoes WHERE id = ?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Conexao.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, idQuestao);
            ps.executeUpdate();
        } finally {
            Conexao.closeConnection(conn, ps, null);
        }
    }

    // --- 5. BUSCAR ALEATÓRIAS (GERAR PROVA) ---

    /**
     * Busca um número específico de questões aleatórias de uma dada disciplina, completas com alternativas.
     */
    public List<Questao> buscarQuestoesAleatorias(String disciplina, int limite) throws SQLException {
        // Reutiliza a função de agrupar para buscar todas e depois filtra
        Map<String, List<Questao>> questoesPorDisciplina = agruparQuestoesPorDisciplina();

        List<Questao> todasDaDisciplina = questoesPorDisciplina.getOrDefault(disciplina, Collections.emptyList());

        if (todasDaDisciplina.isEmpty()) {
            return Collections.emptyList();
        }

        // 1. Embaralha a lista
        Collections.shuffle(todasDaDisciplina);

        // 2. Retorna apenas o número limitado, ou a lista completa se for menor que o limite
        return todasDaDisciplina.subList(0, Math.min(limite, todasDaDisciplina.size()));
    }

    public List<Questao> buscarTodas() {
        return List.of();
    }

    public void salvar(Questao questao) {
    }

    public List<String> buscarDisciplinas() {
        return List.of();
    }
}