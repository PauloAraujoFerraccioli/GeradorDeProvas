package com.geradorprovas.gui;

import com.geradorprovas.service.BancoDeQuestoesService;
import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CadastrarQuestaoPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;
    private final MainFrame mainFrame;

    private JTextField disciplinaField;
    private JTextArea enunciadoArea;
    private JTextField[] alternativaFields;
    private JRadioButton[] corretaButtons;
    private JButton cadastrarButton;

    public CadastrarQuestaoPanel(BancoDeQuestoesService service, MainFrame mainFrame) {
        this.questoesService = service;
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initComponents();
        setupListeners();
    }

    private void initComponents() {
        // --- Painel Central para Enunciado e Alternativas ---
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // 1. Campo de Disciplina
        JPanel disciplinaPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        disciplinaField = new JTextField(20);
        disciplinaPanel.add(new JLabel("Disciplina:"));
        disciplinaPanel.add(disciplinaField);
        centerPanel.add(disciplinaPanel);

        // 2. Enunciado
        enunciadoArea = new JTextArea(6, 50);
        enunciadoArea.setLineWrap(true);
        enunciadoArea.setWrapStyleWord(true);
        JScrollPane enunciadoScroll = new JScrollPane(enunciadoArea);
        enunciadoScroll.setBorder(BorderFactory.createTitledBorder("Enunciado da Questão"));
        centerPanel.add(enunciadoScroll);

        // 3. Alternativas
        JPanel alternativasPanel = new JPanel(new GridLayout(0, 3, 10, 5));
        alternativasPanel.setBorder(BorderFactory.createTitledBorder("Alternativas (Marque a Correta)"));

        alternativaFields = new JTextField[5];
        corretaButtons = new JRadioButton[5];
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < 5; i++) {
            alternativaFields[i] = new JTextField();
            corretaButtons[i] = new JRadioButton();
            group.add(corretaButtons[i]);

            alternativasPanel.add(new JLabel("Alternativa " + (char)('A' + i) + ":"));
            alternativasPanel.add(alternativaFields[i]);
            alternativasPanel.add(corretaButtons[i]);
        }
        centerPanel.add(alternativasPanel);

        add(centerPanel, BorderLayout.CENTER);

        // --- Painel Inferior para Botões ---
        cadastrarButton = new JButton("Cadastrar Nova Questão");
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(cadastrarButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupListeners() {
        cadastrarButton.addActionListener(e -> cadastrarQuestao());
    }

    private void cadastrarQuestao() {
        try {
            String disciplina = disciplinaField.getText().trim();
            String enunciado = enunciadoArea.getText().trim();

            if (disciplina.isEmpty() || enunciado.isEmpty()) {
                throw new IllegalArgumentException("Disciplina e Enunciado não podem ser vazios.");
            }

            List<Alternativa> alternativas = new ArrayList<>();
            boolean encontrouCorreta = false;

            for (int i = 0; i < 5; i++) {
                String textoAlternativa = alternativaFields[i].getText().trim();
                boolean correta = corretaButtons[i].isSelected();

                if (!textoAlternativa.isEmpty()) {
                    Alternativa alt = new Alternativa(null, textoAlternativa, correta);
                    alternativas.add(alt);

                    if (correta) {
                        encontrouCorreta = true;
                    }
                }
            }

            if (alternativas.size() < 2) {
                throw new IllegalArgumentException("A questão deve ter no mínimo 2 alternativas.");
            }
            if (!encontrouCorreta) {
                throw new IllegalArgumentException("Você deve marcar uma alternativa como correta.");
            }

            Questao novaQuestao = new Questao(null, enunciado, disciplina, alternativas);
            questoesService.cadastrarQuestao(novaQuestao);

            limparCampos();
            JOptionPane.showMessageDialog(this, "Questão cadastrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            if (mainFrame != null) {
                mainFrame.recarregarPaineis();
            }

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Erro de Validação: " + e.getMessage(), "Erro", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar no banco de dados: " + e.getMessage(), "Erro Crítico", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void limparCampos() {
        disciplinaField.setText("");
        enunciadoArea.setText("");
        for (int i = 0; i < 5; i++) {
            alternativaFields[i].setText("");
            corretaButtons[i].setSelected(false);
        }
    }
}