package com.geradorprovas.gui; // Pacote da GUI

import javax.swing.SwingUtilities;

public class MainApp {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(MainFrame::new);
    }
}