package com.geradorprovas.gui;

import javax.swing.*;

public class MainApp {

    public static void main(String[] args) {

        // Garante que todos os componentes da interface gráfica
        // sejam criados e manipulados na Event Dispatch Thread (EDT).
        SwingUtilities.invokeLater(() -> {
            try {
                // Cria e exibe a janela principal
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            } catch (Exception e) {
                System.err.println("Erro Crítico ao iniciar a aplicação:");
                e.printStackTrace();
            }
        });
    }
}