package com.geradorprovas.gui;

import javax.swing.*;

public class MainApp {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            } catch (Exception e) {
                System.err.println("Erro Crítico ao iniciar a aplicação:");
                e.printStackTrace();
            }
        });
    }
}