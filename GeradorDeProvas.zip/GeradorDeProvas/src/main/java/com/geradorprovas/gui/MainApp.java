package com.geradorprovas.gui; // Pacote da GUI

import javax.swing.SwingUtilities;

public class MainApp {

    public static void main(String[] args) {

        // Usa SwingUtilities.invokeLater para iniciar a GUI na Event Dispatch Thread (EDT).
        // Isso é crucial para que os componentes Swing se comportem de forma segura e responsiva.
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Instancia o MainFrame (a janela principal) sem passar argumentos.
                // O MainFrame é responsável por inicializar suas dependências (DAO e Service) internamente.
                new MainFrame();
            }
        });

        // Alternativamente, usando sintaxe lambda (mais moderna):
        // SwingUtilities.invokeLater(() -> new MainFrame());
    }
}