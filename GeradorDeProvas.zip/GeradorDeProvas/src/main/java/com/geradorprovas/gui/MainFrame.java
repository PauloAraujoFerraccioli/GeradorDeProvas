package com.geradorprovas.gui;

import com.geradorprovas.dao.QuestaoDAO;
import com.geradorprovas.service.BancoDeQuestoesService;

import javax.swing.*;
import java.awt.*;
import java.util.Optional;

public class MainFrame extends JFrame {

    public static final Font FONT_TITULO = new Font("Arial", Font.BOLD, 16);
    private static final String APP_TITLE = "Gerador de Provas";

    private final BancoDeQuestoesService questoesService;
    private final JTabbedPane tabbedPane;

    public MainFrame() {
        QuestaoDAO questaoDAO = new QuestaoDAO();
        this.questoesService = new BancoDeQuestoesService(questaoDAO);

        setTitle(APP_TITLE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1000, 750)); // Aumentado para acomodar o painel de edição
        setLocationRelativeTo(null);

        this.tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.PLAIN, 14));

        // 1. Aba de Cadastro
        CadastroQuestaoPanel cadastroPanel = new CadastroQuestaoPanel(questoesService, this);
        tabbedPane.addTab("1. Cadastrar Questão (A-E)", cadastroPanel);

        // 2. Aba de Geração
        GerarProvaPanel gerarProvaPanel = new GerarProvaPanel(questoesService, this);
        tabbedPane.addTab("2. Gerar Prova (PDF)", gerarProvaPanel);

        // 3. ABA DE EDIÇÃO/EXCLUSÃO (Nova)
        EditarQuestaoPanel editarQuestaoPanel = new EditarQuestaoPanel(questoesService);
        tabbedPane.addTab("3. Editar/Excluir Questão", editarQuestaoPanel);

        add(tabbedPane, BorderLayout.CENTER);
        pack();
    }

    public void updateGerarProvaPanel() {
        Optional<Component> optionalPanel = java.util.Arrays.stream(tabbedPane.getComponents())
                .filter(c -> c instanceof GerarProvaPanel)
                .findFirst();

        optionalPanel.ifPresent(component -> {
            ((GerarProvaPanel) component).loadDisciplinas();
        });
    }

    // Método para atualizar o painel de edição/exclusão (útil após cadastro ou exclusão)
    public void updateEditarQuestaoPanel() {
        Optional<Component> optionalPanel = java.util.Arrays.stream(tabbedPane.getComponents())
                .filter(c -> c instanceof EditarQuestaoPanel)
                .findFirst();

        optionalPanel.ifPresent(component -> {
            ((EditarQuestaoPanel) component).loadDisciplinasEQuestoes();
        });
    }
}