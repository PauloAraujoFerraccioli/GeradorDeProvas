package com.geradorprovas.gui;

import com.geradorprovas.dao.QuestaoDAO;
import com.geradorprovas.service.BancoDeQuestoesService;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private final BancoDeQuestoesService questoesService;
    private JTabbedPane tabbedPane;

    private GerarProvaPanel gerarProvaPanel;
    private EditarQuestaoPanel editarQuestaoPanel;

    /**
     * Inicializa todas as dependências (DAO/Service) internamente.
     */
    public MainFrame() {
        super("Gerador de Provas | Sistema de Banco de Questões");

        // 1. Inicializa o DAO e o Service INTERNAMENTE
        QuestaoDAO questaoDAO = new QuestaoDAO();
        this.questoesService = new BancoDeQuestoesService(questaoDAO);

        // 2. Configurações básicas da janela
        setupFrame();

        // 3. Montagem da GUI
        setupMenu();
        setupPanels();

        // 4. Exibe a janela
        this.setVisible(true);
    }

    private void setupFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
    }

    private void setupMenu() {
        JMenuBar menuBar = new JMenuBar();
        // Adicione JMenus aqui.
        setJMenuBar(menuBar);
    }

    private void setupPanels() {
        tabbedPane = new JTabbedPane();

        // 1. ABA: Gerar Prova
        gerarProvaPanel = new GerarProvaPanel(questoesService, this);
        tabbedPane.addTab("1. Gerar Prova", gerarProvaPanel);

        // 2. ABA: Cadastrar Questão
        CadastrarQuestaoPanel cadastrarQuestaoPanel = new CadastrarQuestaoPanel(questoesService, this);
        tabbedPane.addTab("2. Cadastrar Questão", cadastrarQuestaoPanel);

        // 3. ABA: Editar e Excluir Questões
        editarQuestaoPanel = new EditarQuestaoPanel(questoesService);
        tabbedPane.addTab("3. Editar/Excluir", editarQuestaoPanel);

        this.add(tabbedPane, BorderLayout.CENTER);
    }

    public void recarregarPaineis() {
        if (gerarProvaPanel != null) {
            gerarProvaPanel.carregarDisciplinas();
        }
        if (editarQuestaoPanel != null) {
            editarQuestaoPanel.loadDisciplinasEQuestoes();
        }
    }

    // --- PONTO DE ENTRADA DA APLICAÇÃO ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}