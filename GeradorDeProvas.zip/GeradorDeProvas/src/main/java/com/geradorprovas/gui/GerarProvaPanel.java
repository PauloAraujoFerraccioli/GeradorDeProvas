package com.geradorprovas.gui;

import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;
import com.geradorprovas.util.GeradorPDF;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import com.itextpdf.text.DocumentException;

public class GerarProvaPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;
    private final MainFrame mainFrame;

    private JTextField txtCurso;
    private JTextField txtTurmaTurno;

    private JComboBox<String> cmbDisciplina;
    private JSpinner spinQuantidade;
    private JTextField txtProfessor;
    private JTextField txtDataProva;
    private JButton btnGerarProva;

    public GerarProvaPanel(BancoDeQuestoesService service, MainFrame mainFrame) {
        this.questoesService = service;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        formPanel.add(new JLabel("Curso:"));
        txtCurso = new JTextField();
        formPanel.add(txtCurso);

        formPanel.add(new JLabel("Turma/Turno:"));
        txtTurmaTurno = new JTextField();
        formPanel.add(txtTurmaTurno);

        formPanel.add(new JLabel("Selecione a Disciplina:"));
        cmbDisciplina = new JComboBox<>();
        formPanel.add(cmbDisciplina);
        carregarDisciplinas();

        formPanel.add(new JLabel("Quantidade de Questões:"));
        spinQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        formPanel.add(spinQuantidade);

        formPanel.add(new JLabel("Nome do Professor(a):"));
        txtProfessor = new JTextField();
        formPanel.add(txtProfessor);

        formPanel.add(new JLabel("Data da Prova (DD-MM-AAAA):"));
        txtDataProva = new JTextField();
        formPanel.add(txtDataProva);


        btnGerarProva = new JButton("Gerar Prova em PDF");
        btnGerarProva.addActionListener(e -> gerarProva());

        this.add(new JScrollPane(formPanel), BorderLayout.CENTER);
        this.add(btnGerarProva, BorderLayout.SOUTH);
    }

    public void carregarDisciplinas() {
        try {
            List<String> disciplinas = questoesService.buscarDisciplinas();
            cmbDisciplina.removeAllItems();
            if (disciplinas.isEmpty()) {
                cmbDisciplina.addItem("Nenhuma disciplina encontrada");
            } else {
                for (String disc : disciplinas) {
                    cmbDisciplina.addItem(disc);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar disciplinas: " + e.getMessage(), "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void gerarProva() {
        String disciplina = (String) cmbDisciplina.getSelectedItem();
        int quantidade = (Integer) spinQuantidade.getValue();
        String professor = txtProfessor.getText().trim();
        String dataProva = txtDataProva.getText().trim();

        String curso = txtCurso.getText().trim();
        String turmaTurno = txtTurmaTurno.getText().trim();

        if (disciplina == null || disciplina.contains("Nenhuma")) {
            JOptionPane.showMessageDialog(this, "Selecione uma disciplina válida.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (professor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O nome do professor é obrigatório.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (curso.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O campo Curso é obrigatório.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (turmaTurno.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O campo Turma/Turno é obrigatório.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            List<Questao> questoesSelecionadas = questoesService.buscarQuestoesAleatorias(disciplina, quantidade);

            if (questoesSelecionadas.size() < quantidade) {
                JOptionPane.showMessageDialog(this,
                        "Apenas " + questoesSelecionadas.size() + " questões encontradas para esta disciplina. Gerando prova com o disponível.",
                        "Aviso", JOptionPane.WARNING_MESSAGE);
            }
            if (questoesSelecionadas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhuma questão encontrada para gerar a prova.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Salvar Prova PDF");

            String nomePadrao = disciplina.replaceAll("[^a-zA-Z0-9_-]", "") + "_Prova_" + dataProva.replaceAll("[^0-9]", "") + ".pdf";
            fileChooser.setSelectedFile(new File(nomePadrao));

            if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                String caminhoCompleto = fileChooser.getSelectedFile().getAbsolutePath();

                if (!caminhoCompleto.toLowerCase().endsWith(".pdf")) {
                    caminhoCompleto += ".pdf";
                }

                GeradorPDF gerador = new GeradorPDF();
                gerador.gerar(
                        curso,
                        turmaTurno,
                        questoesSelecionadas,
                        disciplina,
                        professor,
                        dataProva,
                        caminhoCompleto
                );

                JOptionPane.showMessageDialog(this, "Prova salva com sucesso em:\n" + caminhoCompleto,
                        "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro de Banco de Dados ao buscar questões: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao gerar ou salvar o arquivo PDF: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}