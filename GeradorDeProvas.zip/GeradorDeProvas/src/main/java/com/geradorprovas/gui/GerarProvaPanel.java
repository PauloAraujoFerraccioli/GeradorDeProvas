package com.geradorprovas.gui;

import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;
import com.geradorprovas.util.GeradorPDF;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import com.itextpdf.text.DocumentException;

public class GerarProvaPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;
    private final MainFrame mainFrame; // Assumindo que MainFrame é necessário para navegação

    // Componentes de Seleção
    private JComboBox<String> cmbDisciplina;
    private JSpinner spinQuantidade;
    private JTextField txtProfessor;
    private JTextField txtDataProva; // Campo para a data (Ex: 2025-10-25)
    private JButton btnGerarProva;

    public GerarProvaPanel(BancoDeQuestoesService service, MainFrame mainFrame) {
        this.questoesService = service;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // Disciplina
        formPanel.add(new JLabel("Selecione a Disciplina:"));
        cmbDisciplina = new JComboBox<>();
        formPanel.add(cmbDisciplina);
        carregarDisciplinas(); // Carrega os dados

        // Quantidade de Questões
        formPanel.add(new JLabel("Quantidade de Questões:"));
        spinQuantidade = new JSpinner(new SpinnerNumberModel(5, 1, 100, 1));
        formPanel.add(spinQuantidade);

        // Professor
        formPanel.add(new JLabel("Nome do Professor(a):"));
        txtProfessor = new JTextField();
        formPanel.add(txtProfessor);

        // Data da Prova
        formPanel.add(new JLabel("Data da Prova (AAAA-MM-DD):"));
        txtDataProva = new JTextField("2025-11-09");
        formPanel.add(txtDataProva);


        btnGerarProva = new JButton("Gerar Prova em PDF");
        btnGerarProva.addActionListener(e -> gerarProva());

        // Adiciona painéis ao layout principal
        this.add(new JScrollPane(formPanel), BorderLayout.CENTER);
        this.add(btnGerarProva, BorderLayout.SOUTH);
    }

    public void carregarDisciplinas() {
        try {
            List<String> disciplinas = questoesService.buscarDisciplinas();
            cmbDisciplina.removeAllItems();
            if (disciplinas.isEmpty()) {
                cmbDisciplina.addItem("Nenhuma disciplina encontrada");
            } else {
                for (String disc : disciplinas) {
                    cmbDisciplina.addItem(disc);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar disciplinas: " + e.getMessage(), "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void gerarProva() {
        String disciplina = (String) cmbDisciplina.getSelectedItem();
        int quantidade = (Integer) spinQuantidade.getValue();
        String professor = txtProfessor.getText().trim();
        String dataProva = txtDataProva.getText().trim();

        if (disciplina == null || disciplina.contains("Nenhuma")) {
            JOptionPane.showMessageDialog(this, "Selecione uma disciplina válida.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (professor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O nome do professor é obrigatório.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // 1. Busca as questões aleatórias
            List<Questao> questoesSelecionadas = questoesService.buscarQuestoesAleatorias(disciplina, quantidade);

            if (questoesSelecionadas.size() < quantidade) {
                JOptionPane.showMessageDialog(this,
                        "Apenas " + questoesSelecionadas.size() + " questões encontradas para esta disciplina. Gerando prova com o disponível.",
                        "Aviso", JOptionPane.WARNING_MESSAGE);
            }
            if (questoesSelecionadas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhuma questão encontrada para gerar a prova.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 2. Abre o diálogo para salvar o arquivo
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Salvar Prova PDF");

            // Sugestão de nome do arquivo (limpa caracteres especiais)
            String nomePadrao = disciplina.replaceAll("[^a-zA-Z0-9_-]", "") + "_Prova_" + dataProva.replaceAll("[^0-9]", "") + ".pdf";
            fileChooser.setSelectedFile(new File(nomePadrao));

            if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                String caminhoCompleto = fileChooser.getSelectedFile().getAbsolutePath();

                // 🛠️ CORREÇÃO: Garante que o caminho termine em .pdf, caso o usuário omita a extensão
                if (!caminhoCompleto.toLowerCase().endsWith(".pdf")) {
                    caminhoCompleto += ".pdf";
                }

                // 3. Chama o GeradorPDF
                GeradorPDF gerador = new GeradorPDF();
                gerador.gerar(questoesSelecionadas, disciplina, professor, dataProva, caminhoCompleto);

                // 4. Sucesso
                JOptionPane.showMessageDialog(this, "Prova salva com sucesso em:\n" + caminhoCompleto,
                        "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro de Banco de Dados ao buscar questões: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (DocumentException | IOException e) {
            // 5. Captura erros do iText ou de I/O (permissão, arquivo aberto, etc.)
            JOptionPane.showMessageDialog(this,
                    "ERRO ao salvar o PDF. Verifique as permissões ou se o arquivo já está aberto. Detalhe: " + e.getMessage(),
                    "Erro de Geração de PDF", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}