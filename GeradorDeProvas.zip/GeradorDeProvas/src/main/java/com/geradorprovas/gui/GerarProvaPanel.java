package com.geradorprovas.gui;

import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;
import com.geradorprovas.util.GeradorPDF;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.DocumentException;

public class GerarProvaPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;
    private final MainFrame mainFrame;

    private JComboBox<String> disciplinaComboBox;
    private JTextField professorField;
    private JSpinner numQuestoesSpinner;
    private JButton gerarPdfButton;
    private JLabel countLabel;

    private Map<String, List<Questao>> questoesPorDisciplina = new HashMap<>();

    public GerarProvaPanel(BancoDeQuestoesService service, MainFrame mainFrame) {
        this.questoesService = service;
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initComponents();
        loadDisciplinas();
    }

    private void initComponents() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Disciplina:"), gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        disciplinaComboBox = new JComboBox<>();
        disciplinaComboBox.addActionListener(this::updateQuestionCount);
        formPanel.add(disciplinaComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Professor(a):"), gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        professorField = new JTextField(20);
        formPanel.add(professorField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        formPanel.add(new JLabel("Número de Questões:"), gbc);

        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 100, 1);
        numQuestoesSpinner = new JSpinner(spinnerModel);
        formPanel.add(numQuestoesSpinner, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        countLabel = new JLabel("Questões disponíveis: 0");
        countLabel.setFont(MainFrame.FONT_TITULO);
        formPanel.add(countLabel, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gerarPdfButton = new JButton("Gerar Prova em PDF");
        gerarPdfButton.setPreferredSize(new Dimension(200, 40));
        gerarPdfButton.addActionListener(e -> gerarProva());
        formPanel.add(gerarPdfButton, gbc);

        add(formPanel, BorderLayout.NORTH);
    }

    public void loadDisciplinas() {
        try {
            questoesPorDisciplina = questoesService.agruparQuestoesPorDisciplina();

            disciplinaComboBox.removeAllItems();
            if (questoesPorDisciplina.isEmpty()) {
                disciplinaComboBox.addItem("Nenhuma Disciplina Cadastrada");
                gerarPdfButton.setEnabled(false);
            } else {
                questoesPorDisciplina.keySet().stream().sorted().forEach(disciplinaComboBox::addItem);
                gerarPdfButton.setEnabled(true);
            }

            updateQuestionCount(null);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar disciplinas do banco de dados: " + e.getMessage(),
                    "Erro de SQL", JOptionPane.ERROR_MESSAGE);

            questoesPorDisciplina = new HashMap<>();
            disciplinaComboBox.removeAllItems();
            disciplinaComboBox.addItem("Erro de Conexão");
            gerarPdfButton.setEnabled(false);
            e.printStackTrace();
        }
    }

    private void updateQuestionCount(ActionEvent e) {
        if (this.questoesPorDisciplina.isEmpty()) {
            countLabel.setText("Questões disponíveis: 0");
            return;
        }

        String disciplina = (String) disciplinaComboBox.getSelectedItem();
        int count = 0;

        if (disciplina != null && questoesPorDisciplina.containsKey(disciplina)) {
            count = questoesPorDisciplina.get(disciplina).size();
        }

        SpinnerNumberModel model = (SpinnerNumberModel) numQuestoesSpinner.getModel();
        model.setMaximum(count > 0 ? count : 1);

        countLabel.setText("Questões disponíveis: " + count);
    }


    private void gerarProva() {
        String disciplina = (String) disciplinaComboBox.getSelectedItem();
        String professor = professorField.getText().trim();
        int numQuestoes = (int) numQuestoesSpinner.getValue();

        if (disciplina == null || disciplina.isEmpty() || professor.isEmpty() || numQuestoes <= 0) {
            JOptionPane.showMessageDialog(this,
                    "Preencha todos os campos e certifique-se de que há questões disponíveis.",
                    "Erro de Entrada", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            List<Questao> questoesSelecionadas = questoesService.buscarQuestoesAleatorias(disciplina, numQuestoes);

            if (questoesSelecionadas.size() == 0) {
                JOptionPane.showMessageDialog(this,
                        "Nenhuma questão foi encontrada para a disciplina '" + disciplina + "'.",
                        "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Salvar Prova como PDF");

            String nomeBase = "Prova_" + disciplina.replaceAll("\\s+", "_") + "_"+ java.time.LocalDate.now() + ".pdf";
            fileChooser.setSelectedFile(new File(nomeBase));

            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                String caminhoCompleto = fileToSave.getAbsolutePath();

                if (!caminhoCompleto.toLowerCase().endsWith(".pdf")) {
                    caminhoCompleto += ".pdf";
                }

                GeradorPDF gerador = new GeradorPDF();
                gerador.gerar(questoesSelecionadas, disciplina, professor, caminhoCompleto);

                JOptionPane.showMessageDialog(this,
                        "Prova e Gabarito gerados com sucesso em:\n" + caminhoCompleto,
                        "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao acessar o banco de dados (SQL): " + e.getMessage(),
                    "Erro de SQL", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao gerar o arquivo PDF: " + e.getMessage(),
                    "Erro de Geração", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}