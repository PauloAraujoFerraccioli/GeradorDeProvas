package com.geradorprovas.gui;

import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;

import javax.swing.*;
import java.awt.*;


public class EditarQuestaoPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;

    // Componentes de Seleção
    private JComboBox<String> disciplinaComboBox;
    private JComboBox<Questao> questaoComboBox;
    private JButton carregarButton;

    // Componentes de Edição
    private JTextArea enunciadoArea;
    private JTextField[] alternativaFields;
    private JRadioButton[] corretaButtons;

    private JButton salvarButton;
    private JButton excluirButton;

    // Estado atual da questão carregada
    private Questao questaoAtual;

    public EditarQuestaoPanel(BancoDeQuestoesService service) {
        this.questoesService = service;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initComponents();
        loadDisciplinasEQuestoes(); // Chama o carregamento inicial
    }

    private void initComponents() {

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        disciplinaComboBox = new JComboBox<>();
        questaoComboBox = new JComboBox<>();
        carregarButton = new JButton("Carregar Questão");

        topPanel.add(new JLabel("Disciplina:"));
        topPanel.add(disciplinaComboBox);
        topPanel.add(new JLabel("Questão:"));
        topPanel.add(questaoComboBox);
        topPanel.add(carregarButton);

        add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        // Enunciado
        enunciadoArea = new JTextArea(5, 40);
        enunciadoArea.setBorder(BorderFactory.createTitledBorder("Enunciado da Questão"));
        centerPanel.add(new JScrollPane(enunciadoArea), BorderLayout.NORTH);

        // Alternativas
        JPanel alternativasPanel = new JPanel(new GridLayout(0, 3, 10, 10));
        alternativasPanel.setBorder(BorderFactory.createTitledBorder("Alternativas (Marque a Correta)"));

        alternativaFields = new JTextField[5];
        corretaButtons = new JRadioButton[5];
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < 5; i++) {
            alternativaFields[i] = new JTextField(30);
            corretaButtons[i] = new JRadioButton();
            group.add(corretaButtons[i]);

            alternativasPanel.add(new JLabel("Alternativa " + (char)('A' + i) + ":"));
            alternativasPanel.add(alternativaFields[i]);
            alternativasPanel.add(corretaButtons[i]);
        }

        centerPanel.add(alternativasPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        salvarButton = new JButton("Salvar Alterações");
        excluirButton = new JButton("Excluir Questão");

        bottomPanel.add(salvarButton);
        bottomPanel.add(excluirButton);

        add(bottomPanel, BorderLayout.SOUTH);

        disciplinaComboBox.addActionListener(e -> updateQuestoesComboBox());

    }

    public void loadDisciplinasEQuestoes() {
    }

    private void updateQuestoesComboBox() {
    }
}