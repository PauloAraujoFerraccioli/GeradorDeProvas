package com.geradorprovas.gui;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class EditarQuestaoPanel extends JPanel {

    private final BancoDeQuestoesService questoesService;

    // Componentes de Seleção
    private JComboBox<String> disciplinaComboBox;
    private JComboBox<Questao> questaoComboBox;
    private JButton carregarButton;

    // Componentes de Edição
    private JTextArea enunciadoArea;
    private JTextField[] alternativaFields;
    private JRadioButton[] corretaButtons;

    private JButton salvarButton;
    private JButton excluirButton;

    // Estado atual da questão carregada
    private Questao questaoAtual;

    public EditarQuestaoPanel(BancoDeQuestoesService service) {
        this.questoesService = service;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initComponents();
        loadDisciplinasEQuestoes();
        setupListeners();
        setCamposEdicaoHabilitados(false);
    }

    private void initComponents() {

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        disciplinaComboBox = new JComboBox<>();
        questaoComboBox = new JComboBox<>();
        carregarButton = new JButton("Carregar Questão");

        topPanel.add(new JLabel("Disciplina:"));
        topPanel.add(disciplinaComboBox);
        topPanel.add(new JLabel("Questão:"));
        topPanel.add(questaoComboBox);
        topPanel.add(carregarButton);

        add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        // Enunciado
        enunciadoArea = new JTextArea(5, 40);
        enunciadoArea.setLineWrap(true);
        enunciadoArea.setWrapStyleWord(true);
        enunciadoArea.setBorder(BorderFactory.createTitledBorder("Enunciado da Questão"));
        centerPanel.add(new JScrollPane(enunciadoArea), BorderLayout.NORTH);

        // Alternativas
        JPanel alternativasPanel = new JPanel(new GridLayout(0, 3, 10, 10));
        alternativasPanel.setBorder(BorderFactory.createTitledBorder("Alternativas (Marque a Correta)"));

        alternativaFields = new JTextField[5];
        corretaButtons = new JRadioButton[5];
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < 5; i++) {
            alternativaFields[i] = new JTextField(30);
            corretaButtons[i] = new JRadioButton();
            group.add(corretaButtons[i]);

            alternativasPanel.add(new JLabel("Alternativa " + (char)('A' + i) + ":"));
            alternativasPanel.add(alternativaFields[i]);
            alternativasPanel.add(corretaButtons[i]);
        }

        centerPanel.add(alternativasPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        salvarButton = new JButton("Salvar Alterações");
        excluirButton = new JButton("Excluir Questão");

        bottomPanel.add(salvarButton);
        bottomPanel.add(excluirButton);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    // --- LÓGICA DE CARREGAMENTO DO BANCO DE DADOS ---

    public void loadDisciplinasEQuestoes() {
        SwingUtilities.invokeLater(() -> {
            disciplinaComboBox.removeAllItems();
            questaoComboBox.removeAllItems();
            questaoAtual = null;
            setCamposEdicaoHabilitados(false);

            try {
                // 1. Carregar Disciplinas
                List<String> disciplinas = questoesService.buscarDisciplinas();

                if (disciplinas != null && !disciplinas.isEmpty()) {
                    for (String disciplina : disciplinas) {
                        disciplinaComboBox.addItem(disciplina);
                    }
                    disciplinaComboBox.setSelectedIndex(0);
                    // Dispara a atualização das questões após carregar disciplinas
                    updateQuestoesComboBox();
                } else {
                    disciplinaComboBox.addItem("Nenhuma Disciplina Encontrada");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                        "Erro ao carregar disciplinas: " + e.getMessage(),
                        "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void updateQuestoesComboBox() {
        questaoComboBox.removeAllItems();
        String disciplinaSelecionada = (String) disciplinaComboBox.getSelectedItem();

        if (disciplinaSelecionada != null && !disciplinaSelecionada.equals("Nenhuma Disciplina Encontrada")) {
            try {
                // 2. Carregar Questões
                List<Questao> questoes = questoesService.buscarTodasQuestoesPorDisciplina(disciplinaSelecionada);

                if (questoes != null && !questoes.isEmpty()) {
                    for (Questao questao : questoes) {
                        questaoComboBox.addItem(questao);
                    }
                    questaoComboBox.setSelectedIndex(0);
                } else {
                    questaoComboBox.addItem(null);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                        "Erro ao carregar questões: " + e.getMessage(),
                        "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // --- LÓGICA DE EDIÇÃO E LISTENERS ---

    private void setupListeners() {
        disciplinaComboBox.addActionListener(e -> {
            if (e.getSource() instanceof JComboBox && e.getActionCommand().equals("comboBoxChanged")) {
                updateQuestoesComboBox();
            }
        });

        carregarButton.addActionListener(e -> carregarQuestaoParaEdicao());
        salvarButton.addActionListener(e -> salvarAlteracoes());
        excluirButton.addActionListener(e -> excluirQuestao());
    }

    private void setCamposEdicaoHabilitados(boolean enabled) {
        enunciadoArea.setEnabled(enabled);
        salvarButton.setEnabled(enabled);
        excluirButton.setEnabled(enabled);
        for (int i = 0; i < 5; i++) {
            alternativaFields[i].setEnabled(enabled);
            corretaButtons[i].setEnabled(enabled);
        }
    }

    /**
     * Carrega os dados da Questão selecionada nos campos de edição.
     */
    private void carregarQuestaoParaEdicao() {
        questaoAtual = (Questao) questaoComboBox.getSelectedItem();

        if (questaoAtual == null) {
            JOptionPane.showMessageDialog(this,
                    "Selecione uma questão para carregar.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            setCamposEdicaoHabilitados(false);
            return;
        }

        // Limpa e preenche o Enunciado
        enunciadoArea.setText(questaoAtual.getEnunciado());

        // Limpa e prepara os campos de alternativa
        for (int i = 0; i < 5; i++) {
            alternativaFields[i].setText("");
            corretaButtons[i].setSelected(false);
        }

        // Preenche as Alternativas
        List<Alternativa> alternativas = questaoAtual.getAlternativas();
        if (alternativas != null) {
            for (int i = 0; i < alternativas.size() && i < 5; i++) {
                Alternativa alt = alternativas.get(i);
                alternativaFields[i].setText(alt.getTexto());
                if (alt.isCorreta()) {
                    corretaButtons[i].setSelected(true);
                }
            }
        }

        setCamposEdicaoHabilitados(true);
    }

    // --- IMPLEMENTAÇÃO DO SALVAR ALTERAÇÕES ---

    private void salvarAlteracoes() {
        // Validação agora verifica se o ID é null (para Long)
        if (questaoAtual == null || questaoAtual.getId() == null) {
            JOptionPane.showMessageDialog(this,
                    "Nenhuma questão válida carregada para salvar.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 1. Coletar e Validar o Enunciado
            String novoEnunciado = enunciadoArea.getText().trim();
            if (novoEnunciado.isEmpty()) {
                throw new IllegalArgumentException("O enunciado não pode estar vazio.");
            }
            questaoAtual.setEnunciado(novoEnunciado);

            // 2. Coletar e Validar as Alternativas
            List<Alternativa> novasAlternativas = new ArrayList<>();
            boolean encontrouCorreta = false;

            for (int i = 0; i < 5; i++) {
                String textoAlternativa = alternativaFields[i].getText().trim();
                boolean correta = corretaButtons[i].isSelected();

                if (!textoAlternativa.isEmpty()) {
                    // Nota: O construtor de Alternativa deve aceitar Long para ID se for usá-lo
                    Alternativa alt = new Alternativa(null, textoAlternativa, correta);
                    novasAlternativas.add(alt);

                    if (correta) {
                        encontrouCorreta = true;
                    }
                }
            }

            if (novasAlternativas.size() < 2) {
                throw new IllegalArgumentException("A questão deve ter no mínimo 2 alternativas válidas.");
            }
            if (!encontrouCorreta) {
                throw new IllegalArgumentException("Você deve marcar uma alternativa como correta.");
            }

            // 3. Atualizar o objeto Questão
            questaoAtual.setAlternativas(novasAlternativas);

            // 4. Chamar o Service para persistir as alterações
            questoesService.atualizarQuestao(questaoAtual);

            // 5. Exibir mensagem de sucesso
            JOptionPane.showMessageDialog(this,
                    "Questão ID " + questaoAtual.getId() + " atualizada com sucesso!",
                    "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            loadDisciplinasEQuestoes();
            setCamposEdicaoHabilitados(false);

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro de Validação: " + e.getMessage(),
                    "Erro ao Salvar", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erro de Banco de Dados ao atualizar: " + e.getMessage(),
                    "Erro Crítico", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- IMPLEMENTAÇÃO DO EXCLUIR QUESTÃO ---

    private void excluirQuestao() {
        // Validação agora verifica se o ID é null (para Long)
        if (questaoAtual == null || questaoAtual.getId() == null) {
            JOptionPane.showMessageDialog(this, "Nenhuma questão carregada para exclusão.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String enunciadoCurto = questaoAtual.getEnunciado().length() > 50 ?
                questaoAtual.getEnunciado().substring(0, 50) + "..." :
                questaoAtual.getEnunciado();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Tem certeza que deseja excluir a questão '"+ enunciadoCurto +"' permanentemente?",
                "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Usa Long retornado por getId() e passa para o service
                questoesService.excluirQuestao(questaoAtual.getId());

                JOptionPane.showMessageDialog(this, "Questão excluída com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

                enunciadoArea.setText("");
                setCamposEdicaoHabilitados(false);
                loadDisciplinasEQuestoes();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                        "Erro ao excluir a questão: " + e.getMessage(),
                        "Erro de Exclusão", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}