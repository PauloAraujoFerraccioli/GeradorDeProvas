package com.geradorprovas.dao;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class QuestaoDAOTest1 {

    private QuestaoDAO dao;

    @BeforeEach
    void setUp() {
        this.dao = new QuestaoDAO();
        limparBancoDeDados();
    }

    @AfterEach
    void tearDown() {
        limparBancoDeDados();
    }

    private void limparBancoDeDados() {
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute("SET FOREIGN_KEY_CHECKS = 0");
            stmt.execute("TRUNCATE TABLE alternativas");
            stmt.execute("TRUNCATE TABLE questoes");
            stmt.execute("SET FOREIGN_KEY_CHECKS = 1");

        } catch (SQLException e) {
            fail("Falha na limpeza do banco de dados. Verifique a conexão, as credenciais e o status do MySQL. Erro: " + e.getMessage());
        }
    }

    @Test
    void deveSalvarQuestaoEAlternativasCorretamenteComTransacao() throws SQLException {
        Questao novaQuestao = new Questao("Qual o nome do criador da linguagem Java?", "Programação");
        novaQuestao.adicionarAlternativa(new Alternativa("Linus Torvalds", false));
        novaQuestao.adicionarAlternativa(new Alternativa("James Gosling", true));
        novaQuestao.adicionarAlternativa(new Alternativa("Guido van Rossum", false));
        novaQuestao.adicionarAlternativa(new Alternativa("Bjarne Stroustrup", false));

        dao.salvarQuestao(novaQuestao);

        Long idGerado = 0L;
        assertTrue(idGerado > 0, "O ID gerado deve ser positivo, indicando sucesso na inserção.");

        List<Questao> questoesSalvas = dao.buscarTodas();
        assertEquals(1, questoesSalvas.size(), "Deve haver exatamente 1 questão salva no banco.");

        Questao qSalva = questoesSalvas.get(0);
        assertEquals(idGerado, qSalva.getId(), "O ID da questão buscada deve coincidir com o ID gerado.");
        assertEquals("Programação", qSalva.getDisciplina(), "A disciplina deve ser salva corretamente.");
        assertEquals(4, qSalva.getAlternativas().size(), "O número de alternativas salvas deve ser 4.");

        long corretas = qSalva.getAlternativas().stream().filter(Alternativa::isCorreta).count();
        assertEquals(1, corretas, "Deve haver exatamente 1 alternativa marcada como correta.");

        Optional<Alternativa> respostaCorreta = qSalva.getAlternativas().stream()
                .filter(Alternativa::isCorreta)
                .findFirst();

        assertTrue(respostaCorreta.isPresent(), "Deve haver uma alternativa correta.");
        assertEquals("James Gosling", respostaCorreta.get().getTexto(), "O texto da alternativa correta está incorreto.");
    }

    @Test
    void deveBuscarTodasAsDisciplinasUnicas() throws SQLException {
        dao.salvar(new Questao("Q1", "Fisica"));
        dao.salvar(new Questao("Q2", "Quimica"));
        dao.salvar(new Questao("Q3", "Fisica")); // Disciplina repetida

        List<String> disciplinas = dao.buscarDisciplinas();

        assertEquals(2, disciplinas.size(), "Deve retornar apenas as disciplinas únicas.");

        assertEquals(Arrays.asList("Fisica", "Quimica"), disciplinas, "As disciplinas devem ser buscadas em ordem alfabética.");
    }

    @Test
    void deveRetornarListaVaziaSeBancoEstiverVazio() throws SQLException {

        List<Questao> todas = dao.buscarTodas();

        assertTrue(todas.isEmpty(), "A lista de questões deve ser vazia quando o banco está limpo.");

        List<String> disciplinas = dao.buscarDisciplinas();

        assertTrue(disciplinas.isEmpty(), "A lista de disciplinas deve ser vazia quando o banco está limpo.");
    }
}