package com.geradorprovas.util;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class GeradorPDF {

    private static final Font FONT_TITULO = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.BLACK);
    private static final Font FONT_CABECALHO = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_ENUNCIADO = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.BLACK);
    private static final Font FONT_ALTERNATIVA = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
    private static final Font FONT_GABARITO = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.RED);

    public void gerar(List<Questao> questoesSelecionadas, String disciplina,
                      String professor, String caminhoCompleto)
            throws DocumentException, IOException {

        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, new FileOutputStream(caminhoCompleto));

        document.open();

        gerarConteudoDaProva(document, questoesSelecionadas, disciplina, professor);

        document.newPage();
        gerarGabarito(document, questoesSelecionadas, disciplina);

        document.close();
    }

    private void gerarConteudoDaProva(Document document, List<Questao> questoes,
                                      String disciplina, String professor) throws DocumentException {

        Paragraph titulo = new Paragraph("PROVA DE " + disciplina.toUpperCase(), FONT_TITULO);
        titulo.setAlignment(Element.ALIGN_CENTER);
        document.add(titulo);

        document.add(new Paragraph("Professor(a): " + professor, FONT_CABECALHO));
        document.add(new Paragraph("Data: " + java.time.LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString(), FONT_CABECALHO));
        document.add(new Paragraph("Aluno:______________________ ", FONT_CABECALHO));
        document.add(new Paragraph("Matrícula:___________________ ", FONT_CABECALHO));
        document.add(Chunk.NEWLINE);

        int numQuestao = 1;
        for (Questao q : questoes) {

            Paragraph pEnunciado = new Paragraph(numQuestao + ". " + q.getEnunciado(), FONT_ENUNCIADO);
            pEnunciado.setSpacingAfter(5f);
            document.add(pEnunciado);

            char letra = 'A';
            for (Alternativa alt : q.getAlternativas()) {
                Paragraph pAlternativa = new Paragraph("    " + letra + ") " + alt.getTexto(), FONT_ALTERNATIVA);
                pAlternativa.setSpacingAfter(2f);
                document.add(pAlternativa);
                letra++;
            }

            document.add(Chunk.NEWLINE);
            numQuestao++;
        }
    }

    private void gerarGabarito(Document document, List<Questao> questoes, String disciplina) throws DocumentException {

        Paragraph titulo = new Paragraph("GABARITO - " + disciplina.toUpperCase(), FONT_GABARITO);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20f);
        document.add(titulo);

        int numQuestao = 1;
        for (Questao q : questoes) {
            char letraCorreta = ' ';
            char letraAtual = 'A';

            for (Alternativa alt : q.getAlternativas()) {
                if (alt.isCorreta()) {
                    letraCorreta = letraAtual;
                    break;
                }
                letraAtual++;
            }

            if (letraCorreta != ' ') {
                Paragraph pGabarito = new Paragraph("Questão " + numQuestao + ": " + letraCorreta, FONT_CABECALHO);
                document.add(pGabarito);
            }
            numQuestao++;
        }
    }
}