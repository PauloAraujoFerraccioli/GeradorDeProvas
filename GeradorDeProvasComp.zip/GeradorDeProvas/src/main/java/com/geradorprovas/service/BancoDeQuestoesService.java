package com.geradorprovas.service;

import com.geradorprovas.dao.QuestaoDAO;
import com.geradorprovas.model.Questao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Collections; // Para retornar listas vazias de forma segura

/**
 * Camada de Serviço que orquestra as operações de negócio,
 * validando dados e utilizando a camada DAO para persistência.
 */
public class BancoDeQuestoesService {

    private final QuestaoDAO questaoDAO;

    public BancoDeQuestoesService(QuestaoDAO questaoDAO) {
        this.questaoDAO = questaoDAO;
    }

    // --- MÉTODOS DE CADASTRO ---

    public void cadastrarQuestao(Questao questao) throws IllegalArgumentException, SQLException {
        // Validações básicas de negócio antes de salvar
        if (questao.getEnunciado() == null || questao.getEnunciado().trim().isEmpty()) {
            throw new IllegalArgumentException("O enunciado da questão não pode ser vazio.");
        }
        if (questao.getAlternativas() == null || questao.getAlternativas().size() < 2) {
            throw new IllegalArgumentException("A questão deve ter no mínimo 2 alternativas.");
        }

        questaoDAO.salvarQuestao(questao);
    }

    // --- MÉTODOS DE LISTAGEM / CARREGAMENTO (SUPORTE À EDIÇÃO) ---

    /**
     * Busca todas as questões cadastradas, completas com alternativas,
     * e as agrupa por disciplina. Usado para popular JComboBoxes na GUI.
     */
    public Map<String, List<Questao>> agruparQuestoesPorDisciplina() throws SQLException {
        return questaoDAO.agruparQuestoesPorDisciplina();
    }

    /**
     * Retorna uma lista de todas as disciplinas cadastradas no banco.
     */
    public List<String> listarTodasDisciplinas() throws SQLException {
        // Aproveita o método existente para obter as chaves (disciplinas) do mapa
        Map<String, List<Questao>> questoesPorDisciplina = questaoDAO.agruparQuestoesPorDisciplina();
        // Converte o Set de chaves para List<String>
        return questoesPorDisciplina.keySet().stream().toList();
    }

    /**
     * Retorna uma lista de questões para uma disciplina específica.
     */
    public List<Questao> listarQuestoesPorDisciplina(String disciplina) throws SQLException {
        if (disciplina == null || disciplina.trim().isEmpty()) {
            return Collections.emptyList();
        }
        // Aproveita o método existente para buscar o mapa e filtrar pela disciplina
        Map<String, List<Questao>> questoesPorDisciplina = questaoDAO.agruparQuestoesPorDisciplina();
        // Retorna a lista de questões para a disciplina, ou uma lista vazia se não encontrar
        return questoesPorDisciplina.getOrDefault(disciplina, Collections.emptyList());
    }

    // --- MÉTODOS DE EDIÇÃO ---

    /**
     * Atualiza uma questão (enunciado, disciplina e alternativas) no banco de dados.
     * @param questao O objeto Questao com as novas informações, contendo um ID válido.
     */
    public void atualizarQuestao(Questao questao) throws IllegalArgumentException, SQLException {
        if (questao.getId() == null) {
            throw new IllegalArgumentException("ID da questão é obrigatório para atualização.");
        }
        if (questao.getEnunciado() == null || questao.getEnunciado().trim().isEmpty()) {
            throw new IllegalArgumentException("O enunciado da questão não pode ser vazio.");
        }
        if (questao.getAlternativas() == null || questao.getAlternativas().size() < 2) {
            throw new IllegalArgumentException("A questão deve ter no mínimo 2 alternativas.");
        }

        questaoDAO.atualizarQuestao(questao);
    }

    // --- MÉTODOS DE EXCLUSÃO ---

    /**
     * Exclui uma questão e todas as suas alternativas associadas.
     * @param idQuestao O ID da questão a ser excluída.
     */
    public void excluirQuestao(Long idQuestao) throws SQLException {
        if (idQuestao == null) {
            throw new IllegalArgumentException("ID da questão não pode ser nulo para exclusão.");
        }
        questaoDAO.excluirQuestao(idQuestao);
    }

    // --- MÉTODOS DE GERAÇÃO DE PROVA ---

    /**
     * Busca um conjunto de questões aleatórias e completas para a geração de prova.
     */
    public List<Questao> buscarQuestoesAleatorias(String disciplina, int limite) throws SQLException {
        return questaoDAO.buscarQuestoesAleatorias(disciplina, limite);
    }
}