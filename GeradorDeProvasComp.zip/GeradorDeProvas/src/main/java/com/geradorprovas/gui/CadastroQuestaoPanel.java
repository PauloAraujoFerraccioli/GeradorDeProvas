package com.geradorprovas.gui;

import com.geradorprovas.model.Alternativa;
import com.geradorprovas.model.Questao;
import com.geradorprovas.service.BancoDeQuestoesService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CadastroQuestaoPanel extends JPanel {

    private final BancoDeQuestoesService service;
    private final MainFrame parentFrame;

    private JTextField txtDisciplina;
    private JTextArea txtEnunciado;

    private JTextField[] altFields;
    private JRadioButton[] rbCorretas;
    private ButtonGroup bgCorretas;

    private JButton btnSalvar;

    public CadastroQuestaoPanel(BancoDeQuestoesService service, MainFrame parentFrame) {
        this.service = service;
        this.parentFrame = parentFrame;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        initComponents();
        setupLayout();
    }

    private void initComponents() {
        txtDisciplina = new JTextField(20);

        txtEnunciado = new JTextArea(4, 50);
        txtEnunciado.setLineWrap(true);
        txtEnunciado.setWrapStyleWord(true);

        altFields = new JTextField[5];
        rbCorretas = new JRadioButton[5];
        bgCorretas = new ButtonGroup();

        for (int i = 0; i < 5; i++) {
            altFields[i] = new JTextField(40);
            rbCorretas[i] = new JRadioButton();
            bgCorretas.add(rbCorretas[i]);
        }

        if (rbCorretas.length > 0) {
            rbCorretas[0].setSelected(true);
        }

        btnSalvar = new JButton("Salvar Questão");
        btnSalvar.addActionListener(e -> salvarQuestao());
    }

    private void setupLayout() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lblTitulo = new JLabel("CADASTRO DE NOVA QUESTÃO");
        lblTitulo.setFont(MainFrame.FONT_TITULO);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        formPanel.add(lblTitulo, gbc);

        // Separador
        gbc.gridy++;
        formPanel.add(new JSeparator(), gbc);

        // Disciplina
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        formPanel.add(new JLabel("Disciplina:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        formPanel.add(txtDisciplina, gbc);

        // Enunciado
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Enunciado da Questão:"), gbc);

        gbc.gridy++;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.5;
        formPanel.add(new JScrollPane(txtEnunciado), gbc);

        // Título das Alternativas
        gbc.gridy++;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Alternativas (Marque a Correta):"), gbc);

        // Campos das 5 Alternativas (A-E)
        char letraAtual = 'A';
        for (int i = 0; i < 5; i++) {
            gbc.gridy++;
            gbc.gridx = 0;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.NONE;

            formPanel.add(rbCorretas[i], gbc);

            gbc.gridx = 1;
            formPanel.add(new JLabel(letraAtual + ")"), gbc);

            gbc.gridx = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.weightx = 1.0;
            formPanel.add(altFields[i], gbc);

            letraAtual++;
        }

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(15, 5, 5, 5);
        formPanel.add(btnSalvar, gbc);

        add(formPanel, BorderLayout.CENTER);
    }

    private void salvarQuestao() {
        String disciplina = txtDisciplina.getText().trim();
        String enunciado = txtEnunciado.getText().trim();

        if (disciplina.isEmpty() || enunciado.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, preencha a Disciplina e o Enunciado.",
                    "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Alternativa> alternativas = new ArrayList<>();
        int corretaIndex = -1;

        for (int i = 0; i < 5; i++) {
            String textoAlternativa = altFields[i].getText().trim();

            if (textoAlternativa.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Por favor, preencha o texto para a alternativa " + (char)('A' + i) + ".",
                        "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean isCorreta = rbCorretas[i].isSelected();
            if (isCorreta) {
                corretaIndex = i;
            }

            alternativas.add(new Alternativa(textoAlternativa, isCorreta));
        }

        if (corretaIndex == -1) {
            JOptionPane.showMessageDialog(this,
                    "Você deve selecionar uma alternativa correta.",
                    "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Questao novaQuestao = new Questao(enunciado, disciplina);
            novaQuestao.setAlternativas(alternativas);

            service.cadastrarQuestao(novaQuestao);

            JOptionPane.showMessageDialog(this,
                    "Questão salva com sucesso na disciplina: " + disciplina,
                    "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            limparCampos();
            parentFrame.updateGerarProvaPanel();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao salvar questão no banco de dados: " + ex.getMessage(),
                    "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro inesperado: " + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void limparCampos() {
        txtDisciplina.setText("");
        txtEnunciado.setText("");

        for (JTextField field : altFields) {
            field.setText("");
        }

        if (rbCorretas.length > 0) {
            rbCorretas[0].setSelected(true);
        }
    }
}